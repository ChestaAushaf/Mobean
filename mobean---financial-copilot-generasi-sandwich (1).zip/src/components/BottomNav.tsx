import React from 'react';
import { ActiveTab } from '../types';

interface BottomNavProps {
  currentTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
}

interface NavItem {
  id: ActiveTab;
  label: string;
  icon: string;
}

const NAV_ITEMS: NavItem[] = [
  { id: 'hub', label: 'Hub', icon: 'pie_chart' },
  { id: 'budget', label: 'Budget', icon: 'account_balance_wallet' },
  { id: 'simulator', label: 'Simulator', icon: 'trending_up' },
  { id: 'copilot', label: 'Copilot', icon: 'neurology' },
  { id: 'rewards', label: 'Rewards', icon: 'emoji_events' },
];

export const BottomNav: React.FC<BottomNavProps> = ({ currentTab, onTabChange }) => {
  return (
    <nav className="fixed bottom-0 inset-x-0 z-50 bg-surface/90 backdrop-blur-xl shadow-[0_-4px_20px_rgba(75,0,21,0.04)] border-t border-surface-container-high/60 pb-[env(safe-area-inset-bottom,0px)]">
      <div className="max-w-xl mx-auto flex items-center justify-around h-16 px-1">
        {NAV_ITEMS.map((item) => {
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={`group flex flex-col items-center justify-center flex-1 h-12 transition-colors relative ${
                isActive ? 'text-primary font-bold' : 'text-on-surface-variant hover:text-primary'
              }`}
            >
              {isActive && (
                <span className="absolute top-1 w-6 h-1 rounded-full bg-primary/80 transition-all"></span>
              )}
              <span
                className="material-symbols-outlined text-[24px] transition-transform group-active:scale-90"
                style={{ fontVariationSettings: isActive ? "'FILL' 1" : "'FILL' 0" }}
              >
                {item.icon}
              </span>
              <span className={`text-[11px] mt-0.5 tracking-tight ${isActive ? 'font-bold text-primary' : 'font-medium'}`}>
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
