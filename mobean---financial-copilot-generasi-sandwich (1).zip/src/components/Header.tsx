import React from 'react';
import { ActiveTab, AppViewMode } from '../types';

interface HeaderProps {
  currentTab: ActiveTab;
  viewMode: AppViewMode;
  onToggleViewMode: () => void;
  onNotificationClick: () => void;
  onProfileClick?: () => void;
  unreadCount?: number;
}

const TAB_TITLES: Record<ActiveTab, string> = {
  hub: 'Financial Hub',
  budget: 'Smart Budgeting',
  simulator: 'Fi Simulator',
  copilot: 'Ai Copilot',
  rewards: 'Rewards Streaks',
};

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  viewMode,
  onToggleViewMode,
  onNotificationClick,
  onProfileClick,
  unreadCount = 1,
}) => {
  return (
    <header className="fixed top-0 inset-x-0 z-50 bg-surface/85 backdrop-blur-xl shadow-[0_1px_8px_rgba(75,0,21,0.04)] border-b border-surface-container-high/60">
      <div className="max-w-xl mx-auto h-16 px-4 flex items-center justify-between">
        {/* Left: Avatar & Logo/Title */}
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onProfileClick}
            className="relative transition-transform active:scale-95 focus:outline-none"
            title="Buka Profil Pengguna"
          >
            <img
              src="https://lh3.googleusercontent.com/aida/AEtjO1W5dHH0YDMxtNFyWW41T3eM-RaEEoeZvpsCuEp3e6BwG_nYcWcn0dD9G_BIN0xWanIhlk7xUXPNWG3tffmkD0Lv3TUqcJILmm666co8Kj3-jBkOD8VTiDuUoSp_UVV1mEbtdZ0Cca5hgyLuyykvrf0DC6AxxNHQKy15waR4vibQgNuB-LBajr-InMO4mskRtTV4xQDLZpOwXMtGSReb81eEj83gKEIP7CTA2cSXx-B32mIFMg5gng57FTDQYqaJ_NNqrnoxJ7g5RA"
              alt="Sarah Putri"
              className="w-9 h-9 rounded-full object-cover shadow-[0_2px_8px_rgba(106,21,40,0.15)] ring-1 ring-primary/20"
            />
            <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-secondary ring-2 ring-surface"></span>
          </button>

          <div className="flex flex-col">
            <div className="flex items-center gap-1.5">
              <span className="font-headline-sm text-lg font-bold text-primary tracking-tight leading-none">
                MOBEAN
              </span>
              <span className="px-1.5 py-0.5 rounded-full bg-secondary-fixed/60 text-secondary text-[10px] font-bold uppercase tracking-wider">
                Pro
              </span>
            </div>
            <span className="text-[11px] text-on-surface-variant font-medium leading-none mt-0.5">
              {viewMode === 'onboarding' ? 'Pendaftaran Terpadu' : TAB_TITLES[currentTab]}
            </span>
          </div>
        </div>

        {/* Right: Switcher to Onboarding/Hub & Notification Icon */}
        <div className="flex items-center gap-2">
          <button
            onClick={onToggleViewMode}
            className="px-2.5 py-1 rounded-full bg-surface-container-high hover:bg-surface-container-highest text-primary text-xs font-semibold flex items-center gap-1 transition-all active:scale-95"
            title={viewMode === 'app' ? 'Buka Panduan Pendaftaran' : 'Buka Dashboard'}
          >
            <span className="material-symbols-outlined text-[16px]">
              {viewMode === 'app' ? 'assignment' : 'dashboard'}
            </span>
            <span className="hidden sm:inline">
              {viewMode === 'app' ? 'Pendaftaran (6 Langkah)' : 'Dashboard Hub'}
            </span>
            <span className="sm:hidden">
              {viewMode === 'app' ? 'Daftar' : 'Hub'}
            </span>
          </button>

          <button
            aria-label="Notifikasi"
            onClick={onNotificationClick}
            className="w-10 h-10 relative flex items-center justify-center rounded-full text-on-surface hover:bg-surface-container-high transition-colors"
          >
            <span className="material-symbols-outlined text-[22px]">notifications</span>
            {unreadCount > 0 && (
              <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-secondary ring-2 ring-surface"></span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
