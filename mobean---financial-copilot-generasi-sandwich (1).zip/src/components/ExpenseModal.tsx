import React, { useState } from 'react';
import { BudgetItem } from '../types';
import { formatRupiah } from '../data/mockData';

interface ExpenseModalProps {
  isOpen: boolean;
  onClose: () => void;
  categories: BudgetItem[];
  onAddExpense: (categoryId: string, amount: number, description: string) => void;
}

export const ExpenseModal: React.FC<ExpenseModalProps> = ({
  isOpen,
  onClose,
  categories,
  onAddExpense,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>(categories[0]?.id || 'ortu');
  const [amount, setAmount] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseInt(amount.replace(/\D/g, ''), 10);
    if (!numAmount || numAmount <= 0) return;

    setIsProcessing(true);
    setTimeout(() => {
      onAddExpense(selectedCategory, numAmount, description || 'Pengeluaran rutin');
      setIsProcessing(false);
      setAmount('');
      setDescription('');
      onClose();
    }, 400);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-on-surface/50 backdrop-blur-sm animate-in fade-in">
      <div className="bg-surface-container-lowest p-5 rounded-2xl max-w-sm w-full shadow-2xl animate-in zoom-in-95 duration-200 flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-primary-container text-on-primary flex items-center justify-center">
              <span className="material-symbols-outlined text-[18px]">receipt</span>
            </div>
            <div>
              <h3 className="text-sm font-bold text-on-surface">Catat Pengeluaran Baru</h3>
              <p className="text-[10px] text-on-surface-variant">Update real-time ke Mo-Pocket Anda</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-7 h-7 rounded-full bg-surface-container flex items-center justify-center text-on-surface-variant hover:text-on-surface"
          >
            <span className="material-symbols-outlined text-[16px]">close</span>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3 pt-1">
          <div>
            <label className="text-xs font-semibold text-on-surface block mb-1">Pilih Kategori Pos</label>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full text-xs font-medium bg-surface-container-low rounded-xl px-3 py-2.5 border border-surface-container-high focus:outline-none focus:border-primary text-on-surface"
            >
              {categories.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.title} (Sisa: {formatRupiah(Math.max(0, c.allocated - c.spent))})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-xs font-semibold text-on-surface block mb-1">Nominal (Rp)</label>
            <div className="relative flex items-center">
              <span className="absolute left-3 text-xs font-bold text-primary">Rp</span>
              <input
                type="number"
                required
                placeholder="250000"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full text-sm font-bold bg-surface-container-low rounded-xl pl-10 pr-3 py-2 border border-surface-container-high focus:outline-none focus:border-primary text-on-surface"
              />
            </div>
          </div>

          <div>
            <label className="text-xs font-semibold text-on-surface block mb-1">Catatan / Deskripsi</label>
            <input
              type="text"
              placeholder="Contoh: Beli tensimeter & obat Ibu"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full text-xs bg-surface-container-low rounded-xl px-3 py-2 border border-surface-container-high focus:outline-none focus:border-primary text-on-surface"
            />
          </div>

          <div className="flex items-center gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2.5 rounded-full bg-surface-container text-xs font-semibold text-on-surface hover:bg-surface-container-high transition-colors"
            >
              Batal
            </button>
            <button
              type="submit"
              disabled={isProcessing || !amount}
              className="flex-1 py-2.5 rounded-full bg-primary text-on-primary text-xs font-bold hover:bg-primary-container transition-transform active:scale-95 flex items-center justify-center gap-1 shadow-xs disabled:opacity-50"
            >
              <span className="material-symbols-outlined text-[16px]">save</span>
              <span>{isProcessing ? 'Menyimpan...' : 'Simpan Transaksi'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
