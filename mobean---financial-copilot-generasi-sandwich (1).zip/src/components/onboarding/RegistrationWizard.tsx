import React, { useState, useEffect } from 'react';

interface RegistrationWizardProps {
  onComplete: () => void;
  onBackToApp?: () => void;
}

export const RegistrationWizard: React.FC<RegistrationWizardProps> = ({ onComplete, onBackToApp }) => {
  const [currentStep, setCurrentStep] = useState<number>(1); // Starts at step 1 as requested
  const [regMethod, setRegMethod] = useState<'phone' | 'email'>('phone');
  const [phoneNumber, setPhoneNumber] = useState<string>('812 3456 7890');
  const [emailAddress, setEmailAddress] = useState<string>('sarah.putri@email.com');
  const [fullName, setFullName] = useState<string>('Sarah Putri');
  const [birthDate, setBirthDate] = useState<string>('14/06/1989');
  const [city, setCity] = useState<string>('jkt');

  // OTP State
  const [otpDigits, setOtpDigits] = useState<string[]>(['5', '8', '2', '9', '', '']);
  const [activeOtpIndex, setActiveOtpIndex] = useState<number>(4);
  const [timerSeconds, setTimerSeconds] = useState<number>(154); // 2m 34s

  // Password & Security State
  const [password, setPassword] = useState<string>('Sovereign2025#');
  const [confirmPassword, setConfirmPassword] = useState<string>('Sovereign2025#');
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [securityQuestion, setSecurityQuestion] = useState<string>('mother-city');
  const [securityAnswer, setSecurityAnswer] = useState<string>('Yogyakarta');
  const [biometricsEnabled, setBiometricsEnabled] = useState<boolean>(true);

  // Bank & Preferences
  const [connectedBanks, setConnectedBanks] = useState<{ [key: string]: boolean }>({
    bca: true,
    mandiri: false,
    gopay: false,
    bibit: false,
  });
  const [notifPreferences, setNotifPreferences] = useState({
    copilot: true,
    overbudget: true,
    report: true,
  });

  // Referral & QR Modal
  const [copiedCode, setCopiedCode] = useState<boolean>(false);
  const [copiedLink, setCopiedLink] = useState<boolean>(false);
  const [showQrModal, setShowQrModal] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Countdown timer for OTP
  useEffect(() => {
    if (currentStep !== 2) return;
    const interval = setInterval(() => {
      setTimerSeconds((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(interval);
  }, [currentStep]);

  const formatTimer = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins < 10 ? '0' : ''}${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Numpad input handler for OTP
  const handleNumpadPress = (val: string) => {
    if (val === 'backspace') {
      const newDigits = [...otpDigits];
      const targetIdx = activeOtpIndex > 0 && newDigits[activeOtpIndex] === '' ? activeOtpIndex - 1 : activeOtpIndex;
      newDigits[targetIdx] = '';
      setOtpDigits(newDigits);
      setActiveOtpIndex(Math.max(0, targetIdx));
    } else {
      if (activeOtpIndex < 6) {
        const newDigits = [...otpDigits];
        newDigits[activeOtpIndex] = val;
        setOtpDigits(newDigits);
        setActiveOtpIndex(Math.min(5, activeOtpIndex + 1));
      }
    }
  };

  // Password rules validation
  const ruleLength = password.length >= 8;
  const ruleCase = /[A-Z]/.test(password) && /[a-z]/.test(password);
  const ruleNumber = /[0-9]/.test(password);
  const ruleSymbol = /[^A-Za-z0-9]/.test(password);

  const copyReferral = (isLink: boolean = false) => {
    const code = 'SARAH_K7XM2';
    const text = isLink ? 'https://mobean.app/ref/SARAH_K7XM2' : code;
    navigator.clipboard?.writeText(text);
    if (isLink) {
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    } else {
      setCopiedCode(true);
      setTimeout(() => setCopiedCode(false), 2000);
    }
    showToast(isLink ? 'Tautan referral berhasil disalin!' : 'Kode referral berhasil disalin!');
  };

  const stepMeta = [
    { num: 1, label: 'Kontak', desc: 'Data Diri Awal' },
    { num: 2, label: 'OTP', desc: 'Verifikasi Keamanan' },
    { num: 3, label: 'Profil', desc: 'Demografi & Nafkah' },
    { num: 4, label: 'Sandi', desc: 'Kata Sandi & Proteksi' },
    { num: 5, label: 'Taut', desc: 'Rekening & Preferensi' },
    { num: 6, label: 'Siap', desc: 'Akun Terverifikasi' },
  ];

  return (
    <div className="max-w-xl mx-auto w-full px-4 pt-2 pb-24 relative">
      {/* Ambient background glow */}
      <div className="fixed inset-0 pointer-events-none opacity-30 bg-[radial-gradient(ellipse_80%_50%_at_50%_-20%,rgba(110,12,40,0.25),rgba(255,255,255,0))] -z-10"></div>

      {/* Wizard Progress Navigation Header */}
      <div className="bg-surface-container-low rounded-2xl p-4 shadow-sm mb-4 border border-surface-container-high/60">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs text-primary font-bold uppercase tracking-wider flex items-center gap-1.5">
            <span className="material-symbols-outlined text-[16px] text-secondary">potted_plant</span>
            Pendaftaran Terpadu
          </span>
          <span className="text-xs text-secondary font-bold">
            Langkah {currentStep} dari 6
          </span>
        </div>

        {/* Progress Track */}
        <div className="w-full bg-surface-container-highest h-2 rounded-full overflow-hidden mb-3">
          <div
            className="bg-gradient-to-r from-secondary to-primary h-full transition-all duration-300 ease-out"
            style={{ width: `${(currentStep / 6) * 100}%` }}
          ></div>
        </div>

        {/* 6 Step Micro Selectors */}
        <div className="grid grid-cols-6 gap-1 pt-1">
          {stepMeta.map((s) => {
            const isCurrent = s.num === currentStep;
            const isCompleted = s.num < currentStep;
            return (
              <button
                key={s.num}
                type="button"
                onClick={() => setCurrentStep(s.num)}
                className="flex flex-col items-center group py-1"
              >
                <div
                  className={`w-7 h-7 rounded-full flex items-center justify-center text-xs transition-all font-bold ${
                    isCurrent
                      ? 'bg-primary text-on-primary shadow-md ring-2 ring-secondary-container'
                      : isCompleted
                      ? 'bg-[#2E6347] text-white'
                      : 'bg-surface-container-high text-on-surface-variant hover:bg-primary-fixed/50'
                  }`}
                >
                  {isCompleted ? '✓' : s.num}
                </div>
                <span
                  className={`text-[10px] truncate mt-1 ${
                    isCurrent ? 'text-primary font-bold' : 'text-on-surface-variant'
                  }`}
                >
                  {s.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* ================= STEP 1: DATA DIRI & JALUR VERIFIKASI ================= */}
      {currentStep === 1 && (
        <div className="flex flex-col gap-4 animate-in fade-in duration-300">
          {/* Hero Branding Card */}
          <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-[#4a0010] via-[#5c0d1e] to-[#6b1121] text-on-primary p-5 shadow-xl">
            <div className="absolute -right-8 -top-8 w-44 h-44 rounded-full bg-secondary-container/10 blur-2xl pointer-events-none"></div>
            <div className="relative z-10 flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-2xl bg-surface/10 p-2 backdrop-blur-md shadow-inner flex items-center justify-center mb-3">
                <img
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuD0iBcjb6dg-4ovavdALTqRZc5aYRmD0QKhJXoTExHADcywIy_MfDX0kl0dXHPc3mHv3GOhpLBspdzcivjqdXemoIfav7XhNfCBBQ8HibAuJQvijKo-eDV5RB3IIrw0r_bvaikgU9G8l_n-6HuCZ9BIi9HP1u7owp2yox_8xg4ZdtJk4BDdzLD2_npCSZfYw8l6Pzcq8cp4oqFP4797DnQilO2uA_ZaJMojep5VCEbNnsG4wVINA3hsDVR3g6vw1AQAzA"
                  alt="MOBEAN Logo"
                  className="w-full h-full object-contain drop-shadow-md"
                />
              </div>

              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-surface/15 text-surface text-xs font-semibold mb-2 backdrop-blur-sm">
                <span className="w-1.5 h-1.5 rounded-full bg-secondary-fixed"></span>
                Financial Copilot Generasi Sandwich
              </div>

              <h2 className="text-xl font-bold text-surface tracking-tight mb-2">
                Bebaskan Masa Depan Finansial
              </h2>

              <div className="w-full mt-1 p-3 rounded-xl bg-surface/10 backdrop-blur-md text-left flex items-start gap-2.5 shadow-sm">
                <div className="w-7 h-7 rounded-full bg-secondary-container/20 flex items-center justify-center shrink-0 mt-0.5 text-secondary-fixed">
                  <span className="material-symbols-outlined text-[18px]">spa</span>
                </div>
                <p className="text-xs text-surface-container-low leading-relaxed">
                  Ubah beban ganda nafkah keluarga menjadi{' '}
                  <span className="text-secondary-fixed font-semibold">ketahanan finansial bertumbuh</span> secara terukur.
                </p>
              </div>
            </div>
          </div>

          {/* Registration Input Card */}
          <div className="rounded-2xl bg-surface-container-lowest p-5 shadow-sm border border-surface-container-high/60 flex flex-col gap-4">
            {/* Tab Selector */}
            <div className="flex items-center bg-surface-container p-1 rounded-full">
              <button
                type="button"
                onClick={() => setRegMethod('phone')}
                className={`flex-1 py-2 rounded-full flex items-center justify-center gap-1.5 text-xs font-semibold transition-all ${
                  regMethod === 'phone'
                    ? 'bg-primary text-on-primary shadow-sm'
                    : 'text-on-surface-variant hover:text-on-surface'
                }`}
              >
                <span className="material-symbols-outlined text-[18px]">smartphone</span>
                Nomor Telepon
              </button>
              <button
                type="button"
                onClick={() => setRegMethod('email')}
                className={`flex-1 py-2 rounded-full flex items-center justify-center gap-1.5 text-xs font-semibold transition-all ${
                  regMethod === 'email'
                    ? 'bg-primary text-on-primary shadow-sm'
                    : 'text-on-surface-variant hover:text-on-surface'
                }`}
              >
                <span className="material-symbols-outlined text-[18px]">mail</span>
                Email Pribadi
              </button>
            </div>

            {/* Phone Form */}
            {regMethod === 'phone' ? (
              <div className="flex flex-col gap-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-on-surface flex items-center gap-1">
                    Nomor WhatsApp Aktif
                    <span className="px-2 py-0.5 rounded bg-primary-container text-on-primary text-[10px] font-bold">
                      WAJIB
                    </span>
                  </label>
                  <span className="text-[11px] text-on-surface-variant">Untuk OTP Instan</span>
                </div>

                <div className="flex items-center bg-surface-container-low rounded-xl px-3 py-1 border border-surface-container-high focus-within:border-primary transition-all">
                  <div className="flex items-center gap-1.5 pr-2 mr-2 border-r border-surface-container-highest py-1 shrink-0">
                    <span className="text-sm">🇮🇩</span>
                    <span className="text-sm font-bold text-on-surface">+62</span>
                  </div>
                  <input
                    type="tel"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    placeholder="812 3456 7890"
                    className="w-full bg-transparent py-2.5 text-on-surface text-base font-semibold outline-none"
                  />
                </div>
                <p className="text-[11px] text-on-surface-variant flex items-center gap-1">
                  <span className="material-symbols-outlined text-[15px] text-secondary">verified_user</span>
                  Kode verifikasi OTP 6 digit akan dikirimkan otomatis via WhatsApp / SMS.
                </p>
              </div>
            ) : (
              <div className="flex flex-col gap-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-on-surface flex items-center gap-1">
                    Alamat Email Resmi
                    <span className="px-2 py-0.5 rounded bg-primary-container text-on-primary text-[10px] font-bold">
                      WAJIB
                    </span>
                  </label>
                  <span className="text-[11px] text-on-surface-variant">Aman & Terenkripsi</span>
                </div>
                <div className="flex items-center bg-surface-container-low rounded-xl px-3 py-1 border border-surface-container-high focus-within:border-primary transition-all">
                  <span className="material-symbols-outlined text-on-surface-variant mr-2 text-[18px]">mail</span>
                  <input
                    type="email"
                    value={emailAddress}
                    onChange={(e) => setEmailAddress(e.target.value)}
                    placeholder="sarah.putri@email.com"
                    className="w-full bg-transparent py-2.5 text-on-surface text-sm font-medium outline-none"
                  />
                </div>
              </div>
            )}

            {/* CTA Button */}
            <button
              type="button"
              onClick={() => setCurrentStep(2)}
              className="w-full py-3.5 px-4 rounded-full bg-primary text-on-primary font-bold text-sm shadow-md hover:bg-primary-container transition-all flex items-center justify-center gap-2 active:scale-98"
            >
              <span>Lanjutkan Verifikasi (Langkah 1/6)</span>
              <span className="material-symbols-outlined text-[18px] text-secondary-fixed">arrow_forward</span>
            </button>

            {/* Fast Auth */}
            <div className="flex flex-col items-center pt-1">
              <div className="relative w-full flex items-center justify-center my-2">
                <div className="w-full h-px bg-surface-variant"></div>
                <span className="absolute bg-surface-container-lowest px-3 text-[10px] text-outline uppercase tracking-wider font-semibold">
                  atau daftar cepat dengan
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2.5 w-full mt-2">
                <button
                  type="button"
                  onClick={() => {
                    showToast('Autentikasi Google berhasil diinisiasi.');
                    setCurrentStep(2);
                  }}
                  className="flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-surface-container-low hover:bg-surface-container text-xs font-semibold text-on-surface shadow-xs transition-all active:scale-98"
                >
                  <svg className="w-4 h-4" viewBox="0 0 24 24">
                    <path
                      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                      fill="#4285F4"
                    />
                    <path
                      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                      fill="#34A853"
                    />
                    <path
                      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                      fill="#FBBC05"
                    />
                    <path
                      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                      fill="#EA4335"
                    />
                  </svg>
                  <span>Google</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    showToast('Autentikasi Apple ID berhasil.');
                    setCurrentStep(2);
                  }}
                  className="flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-surface-container-low hover:bg-surface-container text-xs font-semibold text-on-surface shadow-xs transition-all active:scale-98"
                >
                  <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                    <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M15.97 6.37c.61-.75 1.04-1.8 0.92-2.85-.92.04-2.02.62-2.66 1.37-.56.65-1.06 1.7-0.93 2.73 1.03.08 2.07-.5 2.67-1.25z" />
                  </svg>
                  <span>Apple ID</span>
                </button>
              </div>

              <div className="flex items-center gap-1.5 mt-3 text-xs text-on-surface-variant">
                <span>Sudah punya akun MOBEAN?</span>
                <button
                  type="button"
                  onClick={onComplete}
                  className="font-bold text-primary hover:underline"
                >
                  Masuk di sini
                </button>
              </div>
            </div>
          </div>

          {/* OJK Sandboxing & Bank Grade Card */}
          <div className="w-full rounded-2xl bg-surface-container-high/60 p-4 flex items-center justify-between gap-3 text-on-surface-variant border border-surface-container-highest">
            <div className="flex items-center gap-2.5">
              <span className="material-symbols-outlined text-primary text-[22px]">lock</span>
              <div className="flex flex-col">
                <span className="text-xs text-on-surface font-bold">Enkripsi 256-Bit Bank-Grade</span>
                <span className="text-[11px] text-on-surface-variant">Data finansial keluarga terlindungi penuh</span>
              </div>
            </div>
            <div className="flex items-center gap-1 bg-surface-container-lowest px-2.5 py-1 rounded-lg shrink-0 shadow-xs">
              <span className="material-symbols-outlined text-secondary text-[16px]">verified</span>
              <span className="text-[11px] text-on-surface font-bold">OJK Sandboxing</span>
            </div>
          </div>
        </div>
      )}

      {/* ================= STEP 2: OTP VERIFIKASI ================= */}
      {currentStep === 2 && (
        <div className="flex flex-col gap-4 animate-in fade-in duration-300">
          {/* Header Card */}
          <div className="rounded-2xl bg-surface-container-lowest p-5 shadow-sm border border-surface-container-high/60">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-full bg-surface-container-low flex items-center justify-center text-primary shrink-0 shadow-sm">
                <span className="material-symbols-outlined text-[22px]">sms</span>
              </div>
              <div className="flex flex-col">
                <h2 className="text-lg font-bold text-primary tracking-tight">Verifikasi Nomor Telepon</h2>
                <p className="text-xs text-on-surface-variant mt-0.5 leading-snug">
                  Kode 6 digit telah dikirim via SMS ke{' '}
                  <span className="font-bold text-on-surface">+62 {phoneNumber}</span>
                </p>
                <button
                  type="button"
                  onClick={() => setCurrentStep(1)}
                  className="inline-flex items-center gap-1 text-xs text-secondary font-semibold mt-2 self-start hover:underline"
                >
                  <span className="material-symbols-outlined text-[14px]">edit</span>
                  <span>Ubah Nomor</span>
                </button>
              </div>
            </div>
          </div>

          {/* OTP Input Grid */}
          <div className="flex flex-col items-center bg-surface-container-lowest rounded-2xl p-5 shadow-sm border border-surface-container-high/60">
            <label className="text-xs text-on-surface-variant uppercase tracking-widest mb-3 text-center font-bold">
              Masukkan 6 Digit Sandi Sekali Pakai
            </label>

            <div className="grid grid-cols-6 gap-2 w-full max-w-[320px] mb-3">
              {otpDigits.map((digit, idx) => {
                const isActive = idx === activeOtpIndex;
                return (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setActiveOtpIndex(idx)}
                    className={`aspect-square rounded-xl flex items-center justify-center transition-all ${
                      isActive
                        ? 'bg-surface-container-highest border-2 border-primary shadow-sm scale-105'
                        : digit
                        ? 'bg-surface-container-low shadow-inner'
                        : 'bg-surface-container'
                    }`}
                  >
                    {digit ? (
                      <span className="text-2xl font-bold text-primary">{digit}</span>
                    ) : isActive ? (
                      <span className="w-0.5 h-6 bg-primary rounded-full animate-pulse"></span>
                    ) : (
                      <span className="w-2 h-2 rounded-full bg-outline-variant"></span>
                    )}
                  </button>
                );
              })}
            </div>

            {/* Countdown timer */}
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-surface-container text-on-surface-variant text-xs">
              <span className="material-symbols-outlined text-[16px] text-secondary">timer</span>
              <span>
                Kode berlaku 10 menit (<strong className="text-primary">{formatTimer(timerSeconds)}</strong> tersisa)
              </span>
            </div>
          </div>

          {/* Secret Caution Note */}
          <div className="flex items-start gap-3 p-4 rounded-2xl bg-surface-container-low border border-surface-container-high/60">
            <div className="w-8 h-8 rounded-full bg-secondary-container/30 flex items-center justify-center text-secondary shrink-0">
              <span className="material-symbols-outlined text-[20px]">gshield</span>
            </div>
            <div className="flex flex-col">
              <span className="text-xs font-bold text-primary">Penting & Rahasia</span>
              <p className="text-xs text-on-surface-variant mt-0.5 leading-snug">
                Kode OTP bersifat rahasia. Jangan berikan kode ini kepada siapapun termasuk pihak MOBEAN.
              </p>
            </div>
          </div>

          {/* Interactive Numeric Pad */}
          <div className="bg-surface-container-lowest rounded-2xl p-3 shadow-sm border border-surface-container-high/60">
            <div className="grid grid-cols-3 gap-2 w-full text-center">
              {['1', '2', '3', '4', '5', '6', '7', '8', '9', '', '0', 'backspace'].map((keyVal, kIdx) => {
                if (keyVal === '') {
                  return (
                    <div key={kIdx} className="flex items-center justify-center py-3">
                      <span className="w-2 h-2 rounded-full bg-outline-variant"></span>
                    </div>
                  );
                }
                if (keyVal === 'backspace') {
                  return (
                    <button
                      key={kIdx}
                      type="button"
                      onClick={() => handleNumpadPress('backspace')}
                      className="flex items-center justify-center py-3 rounded-xl bg-surface-container-low text-primary active:bg-surface-container-high transition-colors"
                      aria-label="Hapus Digit"
                    >
                      <span className="material-symbols-outlined text-[22px]">backspace</span>
                    </button>
                  );
                }
                return (
                  <button
                    key={kIdx}
                    type="button"
                    onClick={() => handleNumpadPress(keyVal)}
                    className="py-3 rounded-xl bg-surface-container-low text-lg font-bold text-primary active:bg-surface-container-high transition-colors"
                  >
                    {keyVal}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Actions */}
          <div className="flex flex-col gap-2">
            <button
              type="button"
              onClick={() => {
                showToast('OTP Berhasil Diverifikasi!');
                setCurrentStep(3);
              }}
              className="w-full py-3.5 px-4 rounded-full bg-primary text-on-primary font-bold text-sm shadow-md hover:bg-primary-container transition-all flex items-center justify-center gap-2 active:scale-98"
            >
              <span>Verifikasi Kode OTP</span>
              <span className="material-symbols-outlined text-[18px]">check_circle</span>
            </button>

            <div className="grid grid-cols-2 gap-2 mt-1">
              <button
                type="button"
                onClick={() => {
                  setTimerSeconds(180);
                  showToast('Kode SMS baru telah dikirimkan ke ponsel Anda.');
                }}
                className="py-2.5 px-3 rounded-full bg-surface-container-high text-primary text-xs font-semibold flex items-center justify-center gap-1.5 active:bg-surface-container-highest transition-colors"
              >
                <span className="material-symbols-outlined text-[16px]">cached</span>
                <span>Kirim Ulang SMS</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setTimerSeconds(180);
                  showToast('Kode baru telah dikirimkan melalui WhatsApp.');
                }}
                className="py-2.5 px-3 rounded-full bg-surface-container-high text-primary text-xs font-semibold flex items-center justify-center gap-1.5 active:bg-surface-container-highest transition-colors"
              >
                <span className="material-symbols-outlined text-[16px] text-secondary">chat</span>
                <span>Kirim via WhatsApp</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= STEP 3: PROFIL DEMOGRAFI & SANDWICH DETECTION ================= */}
      {currentStep === 3 && (
        <div className="flex flex-col gap-4 animate-in fade-in duration-300">
          <div className="flex flex-col">
            <span className="text-xs text-secondary font-bold uppercase tracking-wider">Identifikasi Demografi</span>
            <h2 className="text-xl font-bold text-primary tracking-tight">Data Pribadi & Profil Nafkah</h2>
            <p className="text-xs text-on-surface-variant mt-1 leading-relaxed">
              Sistem kami secara cerdas memetakan rasio ketergantungan generasi sandwich Anda.
            </p>
          </div>

          <div className="bg-surface-container-lowest rounded-2xl p-5 shadow-sm border border-surface-container-high/60 flex flex-col gap-4">
            {/* Nama Lengkap */}
            <div className="flex flex-col gap-1.5">
              <div className="flex justify-between items-center">
                <label className="text-xs font-bold text-on-surface flex items-center gap-1">
                  Nama Lengkap (Sesuai KTP) <span className="text-error">*</span>
                </label>
                <span className="text-[10px] text-on-surface-variant bg-surface-container px-2 py-0.5 rounded-full font-semibold">
                  Sesuai KTP
                </span>
              </div>
              <div className="relative flex items-center">
                <span className="material-symbols-outlined absolute left-3.5 text-on-surface-variant text-[20px] pointer-events-none">
                  badge
                </span>
                <input
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full pl-11 pr-10 py-3 bg-surface-container-low rounded-xl text-sm font-semibold text-on-surface border border-surface-container-high focus:border-primary outline-none"
                />
                <span className="material-symbols-outlined absolute right-3.5 text-secondary text-[18px]">
                  verified
                </span>
              </div>
            </div>

            {/* Email */}
            <div className="flex flex-col gap-1.5">
              <div className="flex justify-between items-center">
                <label className="text-xs font-bold text-on-surface flex items-center gap-1">
                  Alamat Email Resmi <span className="text-error">*</span>
                </label>
                <span className="text-[11px] text-secondary font-bold">Krusial E-Statement</span>
              </div>
              <div className="relative flex items-center">
                <span className="material-symbols-outlined absolute left-3.5 text-on-surface-variant text-[20px] pointer-events-none">
                  mail
                </span>
                <input
                  type="email"
                  value={emailAddress}
                  onChange={(e) => setEmailAddress(e.target.value)}
                  className="w-full pl-11 pr-10 py-3 bg-surface-container-low rounded-xl text-sm font-semibold text-on-surface border border-surface-container-high focus:border-primary outline-none"
                />
                <span className="material-symbols-outlined absolute right-3.5 text-secondary text-[18px]">
                  lock
                </span>
              </div>
            </div>

            {/* Tanggal Lahir */}
            <div className="flex flex-col gap-1.5">
              <div className="flex justify-between items-center">
                <label className="text-xs font-bold text-on-surface flex items-center gap-1">
                  Tanggal Lahir <span className="text-error">*</span>
                </label>
                <span className="text-[11px] text-primary font-bold bg-primary-fixed px-2 py-0.5 rounded-full">
                  35 Tahun (Terverifikasi)
                </span>
              </div>
              <div className="relative flex items-center">
                <span className="material-symbols-outlined absolute left-3.5 text-on-surface-variant text-[20px] pointer-events-none">
                  calendar_today
                </span>
                <input
                  type="text"
                  value={birthDate}
                  onChange={(e) => setBirthDate(e.target.value)}
                  className="w-full pl-11 pr-10 py-3 bg-surface-container-low rounded-xl text-sm font-semibold text-on-surface border border-surface-container-high focus:border-primary outline-none"
                />
                <span className="material-symbols-outlined absolute right-3.5 text-on-surface-variant text-[18px]">
                  cake
                </span>
              </div>
            </div>

            {/* Domisili */}
            <div className="flex flex-col gap-1.5">
              <div className="flex justify-between items-center">
                <label className="text-xs font-bold text-on-surface">Kota / Wilayah Domisili Nafkah</label>
                <span className="text-[11px] text-on-surface-variant">Indeks Biaya Tier-1</span>
              </div>
              <div className="relative flex items-center">
                <span className="material-symbols-outlined absolute left-3.5 text-on-surface-variant text-[20px] pointer-events-none">
                  location_on
                </span>
                <select
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full pl-11 pr-10 py-3 bg-surface-container-low rounded-xl text-sm font-semibold text-on-surface border border-surface-container-high focus:border-primary outline-none appearance-none cursor-pointer"
                >
                  <option value="jkt">DKI Jakarta (Jabodetabek)</option>
                  <option value="bdg">Bandung Raya (Jawa Barat)</option>
                  <option value="sby">Surabaya & Sekitarnya (Jawa Timur)</option>
                  <option value="smg">Semarang & Sekitarnya (Jawa Tengah)</option>
                  <option value="oth">Wilayah Lainnya di Indonesia</option>
                </select>
                <span className="material-symbols-outlined absolute right-3.5 text-on-surface-variant text-[20px] pointer-events-none">
                  expand_more
                </span>
              </div>
            </div>

            {/* Dynamic Multi-Generational Photos */}
            <div className="grid grid-cols-2 gap-2.5 pt-1">
              <div className="relative h-20 rounded-xl overflow-hidden shadow-sm bg-surface-container">
                <img
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuC1r6Kde1wzgrXln3QiIR9MEaoWukI_DRdTY-li436pouBgN9XJjadyRplXLd_1REcR_ji9SD5m_MDCCp_owgoUOOr2pAlOAWntOM6EIu10PMrLU-8sfTZ8-S9610Mpk6FUWCzUyqlKEVUdVEfJATKIwf8YGJHWetQe37qV7NfWd7JAYepF5xSPedvobI64HlVpimFHWUFgwYGxmbRIk6SrjrgkV_Oy215_u80kPa3D2piee31nbeCb"
                  alt="Ortu Mandiri"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-primary/85 via-primary/20 to-transparent flex items-end p-2">
                  <span className="text-xs text-surface font-semibold flex items-center gap-1">
                    <span className="material-symbols-outlined text-[14px]">elderly</span> Ortu Mandiri
                  </span>
                </div>
              </div>

              <div className="relative h-20 rounded-xl overflow-hidden shadow-sm bg-surface-container">
                <img
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuCvz3ga7WwALd0LTXirZmk5r6CkXGJ3f3z-YEmrqXFfYBibXUbXb83TKrywbKGRPOKTLkR0jPHqy7ew4SbukD4fSLv9PzK7dEAPc4-HU5TTmF8TH2GBI_wj4eNG5bSSTOX_lT4EAhHZzZUBsYbPrUFmyBTWz3qfXrkbvgNQklfaGbtTcznzZM176M7vV2PY9i3Hs0fFzAPtUmoMnm1355pNaulN4fg25OADQ8zW6f1DJCKJTsj94FqA"
                  alt="Dana Anak"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-primary/85 via-primary/20 to-transparent flex items-end p-2">
                  <span className="text-xs text-surface font-semibold flex items-center gap-1">
                    <span className="material-symbols-outlined text-[14px]">school</span> Dana Anak
                  </span>
                </div>
              </div>
            </div>

            {/* Special Bento: Auto-Detection Prime Sandwich */}
            <div className="relative overflow-hidden rounded-2xl bg-surface-container-low p-4 shadow-sm border border-secondary/30 mt-1">
              <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-secondary via-secondary-container to-secondary"></div>
              <div className="flex flex-col gap-2.5">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-secondary-container flex items-center justify-center text-on-secondary-container">
                      <span className="material-symbols-outlined text-[18px]">family_restroom</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-secondary font-bold uppercase tracking-wider block">
                        Kalkulasi Algoritma
                      </span>
                      <span className="text-sm font-bold text-primary">Prime Sandwich (35 Thn)</span>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded-full bg-secondary-fixed text-on-secondary-fixed text-[10px] font-bold">
                    Fase Puncak
                  </span>
                </div>

                {/* Allocation Gauge */}
                <div className="p-2.5 bg-surface-container-lowest rounded-xl flex flex-col gap-1.5">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-on-surface-variant flex items-center gap-1">
                      <span className="material-symbols-outlined text-[15px] text-secondary">analytics</span>
                      Tekanan Beban Finansial
                    </span>
                    <span className="text-primary font-bold">Tinggi (Dual-Care)</span>
                  </div>
                  <div className="flex items-center gap-1.5 w-full h-2 rounded-full overflow-hidden">
                    <div className="h-full bg-primary flex-1" title="Anak (45%)"></div>
                    <div className="h-full bg-secondary flex-1" title="Ortu (35%)"></div>
                    <div className="h-full bg-surface-container-highest w-1/4" title="Sendiri (20%)"></div>
                  </div>
                  <div className="flex justify-between text-[10px] text-on-surface-variant font-medium">
                    <span>Anak (45%)</span>
                    <span>Orang Tua (35%)</span>
                    <span>Sendiri (20%)</span>
                  </div>
                </div>

                <p className="text-xs text-on-surface leading-relaxed">
                  Fase beban ketergantungan ganda maksimal (
                  <strong className="text-primary">Pembiayaan Pendidikan Anak</strong> &amp;{' '}
                  <strong className="text-secondary">Perawatan Kesehatan Ortu Pensiunan</strong>).
                </p>

                <div className="flex items-center gap-2 p-2.5 bg-surface-container-lowest rounded-xl">
                  <span className="material-symbols-outlined text-secondary text-[18px]">shield</span>
                  <div className="flex flex-col">
                    <span className="text-[10px] text-on-surface-variant">Rekomendasi Cadangan Darurat Khusus</span>
                    <span className="text-xs font-bold text-primary">9x Pengeluaran Bulanan Keluarga</span>
                  </div>
                </div>
              </div>
            </div>

            {/* ISO guarantee */}
            <div className="flex items-center justify-center gap-1.5 py-1.5 px-2.5 rounded-lg bg-surface-container-high/60 text-center">
              <span className="material-symbols-outlined text-[16px] text-secondary">gavel</span>
              <p className="text-[11px] text-on-surface-variant">
                Standar <strong className="text-on-surface">ISO/IEC 27001</strong> • Perlindungan Data Finansial 256-bit
              </p>
            </div>
          </div>

          {/* Nav Buttons */}
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => setCurrentStep(2)}
              className="py-3.5 px-5 rounded-full bg-surface-container-high text-on-surface font-semibold text-xs active:scale-95 transition-all"
            >
              Kembali
            </button>
            <button
              type="button"
              onClick={() => setCurrentStep(4)}
              className="flex-1 py-3.5 px-4 rounded-full bg-primary text-on-primary font-bold text-sm shadow-md hover:bg-primary-container transition-all flex items-center justify-center gap-2 active:scale-98"
            >
              <span>Lanjutkan ke Keamanan (Langkah 4/6)</span>
              <span className="material-symbols-outlined text-[18px]">arrow_forward</span>
            </button>
          </div>
        </div>
      )}

      {/* ================= STEP 4: KATA SANDI & KEAMANAN ================= */}
      {currentStep === 4 && (
        <div className="flex flex-col gap-4 animate-in fade-in duration-300">
          <div className="flex flex-col">
            <span className="text-xs text-secondary font-bold uppercase tracking-wider">Perlindungan Kriptografis</span>
            <h2 className="text-xl font-bold text-primary tracking-tight">Buat Kata Sandi & Proteksi</h2>
            <p className="text-xs text-on-surface-variant mt-1 leading-relaxed">
              Lindungi aset dan kedaulatan finansial keluarga Anda dengan sistem keamanan berlapis.
            </p>
          </div>

          <div className="bg-surface-container-lowest rounded-2xl p-5 shadow-sm border border-surface-container-high/60 flex flex-col gap-4">
            {/* Bank Grade Card */}
            <div className="relative overflow-hidden rounded-xl bg-surface-container-low p-3.5 shadow-xs flex items-start gap-2.5">
              <div className="w-8 h-8 rounded-full bg-secondary-container flex items-center justify-center text-on-secondary-container shrink-0">
                <span className="material-symbols-outlined text-[18px]">shield_lock</span>
              </div>
              <div className="flex flex-col">
                <span className="text-xs font-bold text-primary">Enkripsi Tingkat Perbankan</span>
                <span className="text-[11px] text-on-surface-variant leading-relaxed">
                  Seluruh data kas keluarga & warisan terlindungi end-to-end dengan standar ISO 27001.
                </span>
              </div>
            </div>

            {/* Password Input */}
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-bold text-on-surface">Kata Sandi Baru</label>
              <div className="relative flex items-center">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-4 pr-11 py-3 bg-surface-container-low rounded-xl text-sm font-semibold text-on-surface border border-surface-container-high focus:border-primary outline-none"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 text-on-surface-variant hover:text-primary"
                >
                  <span className="material-symbols-outlined text-[18px]">
                    {showPassword ? 'visibility_off' : 'visibility'}
                  </span>
                </button>
              </div>
            </div>

            {/* Password Strength Meter */}
            <div className="p-3 bg-surface-container-low rounded-xl flex flex-col gap-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-on-surface-variant font-medium">Kekuatan Sandi</span>
                <div className="flex items-center gap-1 text-[#2E6347] font-bold">
                  <span className="material-symbols-outlined text-[14px]">eco</span>
                  <span>Sangat Kuat</span>
                </div>
              </div>
              <div className="grid grid-cols-4 gap-1.5 w-full">
                <div className="h-1.5 rounded-full bg-secondary"></div>
                <div className="h-1.5 rounded-full bg-secondary"></div>
                <div className="h-1.5 rounded-full bg-secondary"></div>
                <div className="h-1.5 rounded-full bg-secondary-container"></div>
              </div>
            </div>

            {/* Checklist */}
            <div className="grid grid-cols-1 gap-1.5 px-1 text-xs">
              <div className={`flex items-center gap-2 ${ruleLength ? 'text-[#2E6347]' : 'text-outline'}`}>
                <span className="material-symbols-outlined text-[16px]">check_circle</span>
                <span>Minimal 8 karakter</span>
              </div>
              <div className={`flex items-center gap-2 ${ruleCase ? 'text-[#2E6347]' : 'text-outline'}`}>
                <span className="material-symbols-outlined text-[16px]">check_circle</span>
                <span>Kombinasi huruf besar & huruf kecil</span>
              </div>
              <div className={`flex items-center gap-2 ${ruleNumber ? 'text-[#2E6347]' : 'text-outline'}`}>
                <span className="material-symbols-outlined text-[16px]">check_circle</span>
                <span>Memuat angka (0-9)</span>
              </div>
              <div className={`flex items-center gap-2 ${ruleSymbol ? 'text-[#2E6347]' : 'text-outline'}`}>
                <span className="material-symbols-outlined text-[16px]">check_circle</span>
                <span>Karakter spesial atau simbol (!@#$%^&*)</span>
              </div>
            </div>

            {/* Confirm Password */}
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-bold text-on-surface">Konfirmasi Kata Sandi</label>
              <div className="relative flex items-center">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full pl-4 pr-11 py-3 bg-surface-container-low rounded-xl text-sm font-semibold text-on-surface border border-surface-container-high focus:border-primary outline-none"
                />
                <div className="absolute right-3 text-[#2E6347]">
                  <span className="material-symbols-outlined text-[18px]">check_circle</span>
                </div>
              </div>
            </div>

            {/* Security Question */}
            <div className="flex flex-col gap-2 pt-1">
              <label className="text-xs font-bold text-on-surface">Pertanyaan Keamanan Akun</label>
              <div className="relative">
                <select
                  value={securityQuestion}
                  onChange={(e) => setSecurityQuestion(e.target.value)}
                  className="w-full pl-3.5 pr-9 py-2.5 bg-surface-container-low rounded-xl text-xs font-semibold text-on-surface border border-surface-container-high outline-none appearance-none"
                >
                  <option value="mother-city">Kota kelahiran ibu kandung Anda?</option>
                  <option value="first-pet">Nama hewan peliharaan pertama keluarga?</option>
                  <option value="elementary">Nama sekolah dasar favorit masa kecil?</option>
                </select>
                <span className="material-symbols-outlined absolute right-3 top-1/2 -translate-y-1/2 text-on-surface-variant text-[18px] pointer-events-none">
                  expand_more
                </span>
              </div>
              <input
                type="text"
                value={securityAnswer}
                onChange={(e) => setSecurityAnswer(e.target.value)}
                placeholder="Jawaban rahasia..."
                className="w-full px-3.5 py-2.5 bg-surface-container-low rounded-xl text-xs font-semibold text-on-surface border border-surface-container-high outline-none"
              />
            </div>

            {/* Biometric Toggle Switch */}
            <div className="flex items-center justify-between p-3.5 bg-surface-container-low rounded-xl border border-surface-container-high/60">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                  <span className="material-symbols-outlined text-[22px]">fingerprint</span>
                </div>
                <div className="flex flex-col">
                  <span className="text-xs font-bold text-on-surface">Autentikasi Biometrik</span>
                  <span className="text-[11px] text-on-surface-variant">Face ID & Sidik Jari Aktif</span>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setBiometricsEnabled(!biometricsEnabled)}
                className={`w-12 h-6 rounded-full transition-colors relative flex items-center p-0.5 ${
                  biometricsEnabled ? 'bg-primary' : 'bg-surface-container-highest'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white shadow-md transform transition-transform flex items-center justify-center ${
                    biometricsEnabled ? 'translate-x-6 text-primary' : 'translate-x-0'
                  }`}
                >
                  {biometricsEnabled && (
                    <span className="material-symbols-outlined text-[13px] font-bold">check</span>
                  )}
                </div>
              </button>
            </div>
          </div>

          {/* Nav Buttons */}
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => setCurrentStep(3)}
              className="py-3.5 px-5 rounded-full bg-surface-container-high text-on-surface font-semibold text-xs active:scale-95 transition-all"
            >
              Kembali
            </button>
            <button
              type="button"
              onClick={() => setCurrentStep(5)}
              className="flex-1 py-3.5 px-4 rounded-full bg-primary text-on-primary font-bold text-sm shadow-md hover:bg-primary-container transition-all flex items-center justify-center gap-2 active:scale-98"
            >
              <span>Lanjutkan ke Setup Rekening (Langkah 5/6)</span>
              <span className="material-symbols-outlined text-[18px]">arrow_forward</span>
            </button>
          </div>
        </div>
      )}

      {/* ================= STEP 5: REKENING & PREFERENSI ================= */}
      {currentStep === 5 && (
        <div className="flex flex-col gap-4 animate-in fade-in duration-300">
          <div className="flex flex-col">
            <div className="flex items-center justify-between">
              <span className="text-xs text-secondary font-bold uppercase tracking-wider">Integrasi Kas</span>
              <span className="bg-secondary-fixed/50 text-secondary text-[10px] font-bold px-2 py-0.5 rounded-full">
                Opsional • Dapat Dihubungkan Nanti
              </span>
            </div>
            <h2 className="text-xl font-bold text-primary tracking-tight mt-1">
              Hubungkan Rekening & Preferensi
            </h2>
            <p className="text-xs text-on-surface-variant mt-1 leading-relaxed">
              Mulai agregasi pintar 4 pilar kas Anda secara otomatis tanpa perlu pencatatan manual yang melelahkan.
            </p>
          </div>

          <div className="bg-surface-container-lowest rounded-2xl p-5 shadow-sm border border-surface-container-high/60 flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-on-surface">Pilih Akun Terhubung</h3>
              <span className="text-[10px] text-on-primary bg-primary px-2 py-0.5 rounded-full font-semibold">
                Otomatisasi 256-bit
              </span>
            </div>

            {/* Bank Accounts */}
            <div className="flex flex-col gap-2.5">
              {/* BCA */}
              <div className="bg-surface-container-low rounded-xl p-3.5 flex items-center justify-between border border-surface-container-high/60">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-10 h-10 rounded-xl bg-surface-container-lowest flex items-center justify-center text-primary font-bold text-xs shadow-xs">
                    BCA
                  </div>
                  <div className="flex flex-col min-w-0">
                    <span className="text-xs font-bold text-on-surface truncate">BCA (Bank Central Asia)</span>
                    <span className="text-[11px] text-on-surface-variant truncate">Rekening Penggajian • ****8492</span>
                  </div>
                </div>
                <div className="shrink-0 flex items-center gap-1 bg-surface-container-lowest px-2.5 py-1 rounded-full shadow-xs">
                  <span className="w-1.5 h-1.5 rounded-full bg-secondary"></span>
                  <span className="text-[10px] font-bold text-primary">Tersambung (Utama)</span>
                </div>
              </div>

              {/* Mandiri */}
              <button
                type="button"
                onClick={() => {
                  setConnectedBanks((prev) => ({ ...prev, mandiri: !prev.mandiri }));
                  showToast(connectedBanks.mandiri ? 'Koneksi Mandiri dinonaktifkan' : 'Bank Mandiri berhasil ditautkan!');
                }}
                className="w-full text-left bg-surface-container-low hover:bg-surface-container rounded-xl p-3.5 flex items-center justify-between border border-surface-container-high/60 transition-all active:scale-[0.99]"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-10 h-10 rounded-xl bg-surface-container-lowest flex items-center justify-center text-secondary font-bold text-xs shadow-xs">
                    MDR
                  </div>
                  <div className="flex flex-col min-w-0">
                    <span className="text-xs font-bold text-on-surface truncate">Bank Mandiri</span>
                    <span className="text-[11px] text-on-surface-variant truncate">Tabungan Operasional & Darurat</span>
                  </div>
                </div>
                <div className="shrink-0 flex items-center gap-1 bg-surface-container-lowest px-2.5 py-1 rounded-full shadow-xs">
                  <span className="material-symbols-outlined text-primary text-[14px]">
                    {connectedBanks.mandiri ? 'check' : 'add'}
                  </span>
                  <span className="text-[10px] font-bold text-primary">
                    {connectedBanks.mandiri ? 'Terhubung' : 'Sambungkan'}
                  </span>
                </div>
              </button>

              {/* GoPay */}
              <button
                type="button"
                onClick={() => {
                  setConnectedBanks((prev) => ({ ...prev, gopay: !prev.gopay }));
                  showToast(connectedBanks.gopay ? 'GoPay dilepas' : 'GoPay Tabungan berhasil disambungkan!');
                }}
                className="w-full text-left bg-surface-container-low hover:bg-surface-container rounded-xl p-3.5 flex items-center justify-between border border-surface-container-high/60 transition-all active:scale-[0.99]"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-10 h-10 rounded-xl bg-surface-container-lowest flex items-center justify-center text-tertiary font-bold text-xs shadow-xs">
                    GPY
                  </div>
                  <div className="flex flex-col min-w-0">
                    <span className="text-xs font-bold text-on-surface truncate">GoPay Tabungan</span>
                    <span className="text-[11px] text-on-surface-variant truncate">Bunga harian & Pengeluaran harian</span>
                  </div>
                </div>
                <div className="shrink-0 flex items-center gap-1 bg-surface-container-lowest px-2.5 py-1 rounded-full shadow-xs">
                  <span className="material-symbols-outlined text-primary text-[14px]">
                    {connectedBanks.gopay ? 'check' : 'add'}
                  </span>
                  <span className="text-[10px] font-bold text-primary">
                    {connectedBanks.gopay ? 'Terhubung' : 'Sambungkan'}
                  </span>
                </div>
              </button>

              {/* Bibit */}
              <button
                type="button"
                onClick={() => {
                  setConnectedBanks((prev) => ({ ...prev, bibit: !prev.bibit }));
                  showToast(connectedBanks.bibit ? 'Bibit dilepas' : 'Bibit Reksadana terhubung!');
                }}
                className="w-full text-left bg-surface-container-low hover:bg-surface-container rounded-xl p-3.5 flex items-center justify-between border border-surface-container-high/60 transition-all active:scale-[0.99]"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-10 h-10 rounded-xl bg-surface-container-lowest flex items-center justify-center text-primary-container font-bold text-xs shadow-xs">
                    BIBIT
                  </div>
                  <div className="flex flex-col min-w-0">
                    <span className="text-xs font-bold text-on-surface truncate">Bibit Reksadana / SBN</span>
                    <span className="text-[11px] text-on-surface-variant truncate">Portofolio Dana Pensiun & Anak</span>
                  </div>
                </div>
                <div className="shrink-0 flex items-center gap-1 bg-surface-container-lowest px-2.5 py-1 rounded-full shadow-xs">
                  <span className="material-symbols-outlined text-primary text-[14px]">
                    {connectedBanks.bibit ? 'check' : 'add'}
                  </span>
                  <span className="text-[10px] font-bold text-primary">
                    {connectedBanks.bibit ? 'Terhubung' : 'Sambungkan'}
                  </span>
                </div>
              </button>
            </div>

            {/* 4 Pilar Hint Banner */}
            <div className="bg-primary-container text-on-primary rounded-xl p-3.5 shadow-sm">
              <div className="flex items-start gap-2.5">
                <span className="material-symbols-outlined text-secondary-fixed text-[20px] shrink-0 mt-0.5">
                  auto_awesome
                </span>
                <div className="flex flex-col">
                  <span className="text-xs font-bold text-secondary-fixed">
                    Integrasi 4 Pilar Sandwich Generation
                  </span>
                  <p className="text-[11px] text-surface-container-low mt-0.5 leading-snug">
                    Saldo terhubung akan dipetakan langsung ke Pos Orang Tua, Dana Anak, Diri Sendiri, dan Cadangan Darurat.
                  </p>
                </div>
              </div>
            </div>

            {/* Notification Preferences */}
            <div className="flex flex-col gap-2 pt-1">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-on-surface">Preferensi Notifikasi Pintar</span>
                <span className="text-[10px] text-on-surface-variant">Personalisasi AI</span>
              </div>

              {/* Toggle 1 */}
              <div
                onClick={() =>
                  setNotifPreferences((p) => ({ ...p, copilot: !p.copilot }))
                }
                className="flex items-center justify-between p-3 bg-surface-container-low rounded-xl cursor-pointer select-none"
              >
                <div className="flex items-center gap-2.5">
                  <span className="material-symbols-outlined text-secondary text-[20px]">psychology</span>
                  <div className="flex flex-col">
                    <span className="text-xs font-bold text-on-surface">Notifikasi Insight Harian AI Copilot</span>
                    <span className="text-[11px] text-on-surface-variant">Saran cerdas efisiensi pengeluaran keluarga</span>
                  </div>
                </div>
                <div
                  className={`w-10 h-5 rounded-full p-0.5 transition-colors ${
                    notifPreferences.copilot ? 'bg-primary' : 'bg-surface-container-highest'
                  }`}
                >
                  <div
                    className={`w-4 h-4 rounded-full bg-white transition-transform ${
                      notifPreferences.copilot ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  ></div>
                </div>
              </div>

              {/* Toggle 2 */}
              <div
                onClick={() =>
                  setNotifPreferences((p) => ({ ...p, overbudget: !p.overbudget }))
                }
                className="flex items-center justify-between p-3 bg-surface-container-low rounded-xl cursor-pointer select-none"
              >
                <div className="flex items-center gap-2.5">
                  <span className="material-symbols-outlined text-error text-[20px]">warning</span>
                  <div className="flex flex-col">
                    <span className="text-xs font-bold text-on-surface">Alert Batas Anggaran & Overbudget</span>
                    <span className="text-[11px] text-on-surface-variant">Peringatan bila pos darurat terserap &gt;70%</span>
                  </div>
                </div>
                <div
                  className={`w-10 h-5 rounded-full p-0.5 transition-colors ${
                    notifPreferences.overbudget ? 'bg-primary' : 'bg-surface-container-highest'
                  }`}
                >
                  <div
                    className={`w-4 h-4 rounded-full bg-white transition-transform ${
                      notifPreferences.overbudget ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  ></div>
                </div>
              </div>

              {/* Toggle 3 */}
              <div
                onClick={() =>
                  setNotifPreferences((p) => ({ ...p, report: !p.report }))
                }
                className="flex items-center justify-between p-3 bg-surface-container-low rounded-xl cursor-pointer select-none"
              >
                <div className="flex items-center gap-2.5">
                  <span className="material-symbols-outlined text-primary text-[20px]">family_restroom</span>
                  <div className="flex flex-col">
                    <span className="text-xs font-bold text-on-surface">Laporan Bebas Sandwich Bulanan</span>
                    <span className="text-[11px] text-on-surface-variant">Evaluasi skor kemandirian & kesiapan pensiun</span>
                  </div>
                </div>
                <div
                  className={`w-10 h-5 rounded-full p-0.5 transition-colors ${
                    notifPreferences.report ? 'bg-primary' : 'bg-surface-container-highest'
                  }`}
                >
                  <div
                    className={`w-4 h-4 rounded-full bg-white transition-transform ${
                      notifPreferences.report ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  ></div>
                </div>
              </div>
            </div>

            {/* Privacy Badge */}
            <div className="bg-surface-container-low rounded-xl p-3 flex items-center gap-2 text-[11px] text-on-surface-variant">
              <span className="material-symbols-outlined text-secondary text-[18px]">lock</span>
              <span>
                Privasi terlindungi: Enkripsi sekelas perbankan via <strong>TLS 1.3</strong>.
              </span>
            </div>
          </div>

          {/* Action CTAs */}
          <div className="flex flex-col gap-2">
            <button
              type="button"
              onClick={() => setCurrentStep(6)}
              className="w-full py-4 px-6 rounded-full bg-primary text-on-primary font-bold text-sm shadow-md hover:bg-primary-container transition-all flex items-center justify-center gap-2 active:scale-98"
            >
              <span>Selesaikan & Buat Akun</span>
              <span className="material-symbols-outlined text-[18px]">arrow_forward</span>
            </button>
            <button
              type="button"
              onClick={() => setCurrentStep(6)}
              className="w-full py-3 px-4 rounded-full bg-surface-container-high text-primary font-semibold text-xs text-center hover:bg-surface-container-highest transition-colors"
            >
              Lewati Penautan Bank Dulu
            </button>
          </div>
        </div>
      )}

      {/* ================= STEP 6: PENDAFTARAN SELESAI ================= */}
      {currentStep === 6 && (
        <div className="flex flex-col gap-4 animate-in fade-in duration-300">
          {/* Success Banner */}
          <div className="relative overflow-hidden rounded-2xl bg-surface-container-lowest p-6 shadow-sm border border-surface-container-high/60 text-center flex flex-col items-center">
            <div className="relative w-20 h-20 mb-3 flex items-center justify-center">
              <div className="absolute inset-0 rounded-full bg-secondary-fixed/40 animate-ping opacity-60"></div>
              <div className="relative w-16 h-16 rounded-full bg-gradient-to-tr from-secondary-container to-secondary-fixed flex items-center justify-center shadow-md">
                <span className="material-symbols-outlined text-primary text-[36px]" style={{ fontVariationSettings: "'FILL' 1" }}>
                  spa
                </span>
              </div>
              <span className="absolute -top-1 -right-1 text-2xl animate-bounce">🎉</span>
            </div>

            <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-surface-container mb-2">
              <span className="w-1.5 h-1.5 rounded-full bg-secondary"></span>
              <span className="text-[10px] text-secondary font-bold uppercase tracking-wider">
                Perjalanan Mandiri Dimulai
              </span>
            </div>

            <h2 className="text-2xl font-bold text-primary mb-1">Selamat Datang, Sarah!</h2>
            <p className="text-xs text-on-surface-variant max-w-xs leading-relaxed">
              Akun Anda resmi aktif. Mari bersama melangkah menuju kemandirian dan kebebasan generasi sandwich.
            </p>

            <div className="mt-4 pt-3 flex items-center justify-center gap-3 border-t border-surface-container-high w-full">
              <img
                src="https://lh3.googleusercontent.com/aida/AEtjO1WPIp4x2eSQf73NoaHzQSxnh1383PkZebwA8gFbeEuQ07Aj1xFxXS7e--1mcxZaoyZVAhavA-gPwtkgkhakhrmrcoVbWNzBdgoGFkQNaMvq1xJIAHDLeUMtc3r6h2j3EyszvQkTL3uIp9YpvNVhrMIxHF9FzxB65j1716daS2odTSw4OzHX02rjjBVPb38e56D0m9lpIpfXTlF2eG7oQG1sDIfa8xj-flGpVhuk17CXgYA3faQ8G4pZp3I"
                alt="Sarah Putri"
                className="w-9 h-9 rounded-full object-cover shadow-xs ring-1 ring-primary/30"
              />
              <div className="text-left">
                <div className="text-xs font-bold text-on-surface">Sarah Putri</div>
                <div className="text-[10px] text-outline font-medium">Tier: Sandwich Trailblazer 🌿</div>
              </div>
            </div>
          </div>

          {/* Bonus & Referral Card */}
          <div className="rounded-2xl bg-gradient-to-br from-primary-container via-tertiary-container to-primary text-on-primary p-5 shadow-md relative overflow-hidden">
            <div className="flex items-center justify-between mb-2.5">
              <div className="flex items-center gap-1.5">
                <span className="p-1 rounded-lg bg-white/10 text-secondary-fixed">
                  <span className="material-symbols-outlined text-[16px]">redeem</span>
                </span>
                <span className="text-xs text-secondary-fixed font-bold tracking-wide uppercase">
                  Kode Referral Unik Anda
                </span>
              </div>
              <span className="px-2 py-0.5 rounded-full bg-secondary-container text-on-secondary-container text-[10px] font-bold">
                +Rp 50.000 / teman
              </span>
            </div>

            <div className="bg-black/25 rounded-xl p-3 mb-2.5 flex items-center justify-between backdrop-blur-sm">
              <div className="min-w-0 pr-2">
                <span className="text-[10px] text-primary-fixed-dim block">Kode Referral</span>
                <span className="text-lg tracking-wider font-bold text-white font-mono">SARAH_K7XM2</span>
              </div>
              <button
                type="button"
                onClick={() => copyReferral(false)}
                className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-secondary-container text-on-secondary-container text-xs font-bold hover:bg-secondary-fixed transition-all active:scale-95 shadow-sm"
              >
                <span className="material-symbols-outlined text-[15px]">content_copy</span>
                <span>{copiedCode ? 'Disalin!' : 'Salin'}</span>
              </button>
            </div>

            <div className="flex items-center justify-between bg-white/10 rounded-lg px-3 py-2 mb-3">
              <span className="text-[11px] text-primary-fixed truncate">mobean.app/ref/SARAH_K7XM2</span>
              <button
                type="button"
                onClick={() => copyReferral(true)}
                className="text-secondary-fixed hover:text-white transition-colors text-[11px] font-semibold flex items-center gap-1 shrink-0 ml-2"
              >
                <span className="material-symbols-outlined text-[14px]">link</span>
                <span>{copiedLink ? 'Disalin!' : 'Salin Link'}</span>
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => {
                  const text = encodeURIComponent(
                    'Halo! Saya baru saja memulai perencanaan finansial di Mobean untuk keluarga sandwich. Gunakan kode SARAH_K7XM2 dan dapatkan bonus Rp50.000 saat bergabung: https://mobean.app/ref/SARAH_K7XM2'
                  );
                  window.open(`https://api.whatsapp.com/send?text=${text}`, '_blank');
                }}
                className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-full bg-surface-container-lowest text-primary text-xs font-bold shadow-sm hover:bg-surface transition-all active:scale-98"
              >
                <span className="material-symbols-outlined text-secondary text-[18px]">chat</span>
                <span>Bagikan ke WA</span>
              </button>

              <button
                type="button"
                onClick={() => setShowQrModal(true)}
                className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-full bg-white/20 text-white hover:bg-white/30 text-xs font-bold shadow-sm transition-all active:scale-98"
              >
                <span className="material-symbols-outlined text-[18px]">qr_code_2</span>
                <span>QR Preview</span>
              </button>
            </div>
          </div>

          {/* Quick Steps Checklist */}
          <div className="rounded-2xl bg-surface-container-low p-4 shadow-xs border border-surface-container-high/60">
            <div className="flex items-center justify-between mb-3 px-1">
              <h3 className="text-xs text-primary font-bold">Langkah Cepat Selanjutnya</h3>
              <span className="text-[10px] text-outline font-medium">Siap Dilanjutkan</span>
            </div>

            <div className="flex flex-col gap-2">
              <div className="flex items-center justify-between p-3 rounded-xl bg-surface-container-lowest">
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className="w-6 h-6 rounded-full bg-secondary-fixed flex items-center justify-center text-on-secondary-fixed shrink-0">
                    <span className="material-symbols-outlined text-[14px] font-bold">check</span>
                  </div>
                  <div className="min-w-0">
                    <span className="text-xs font-bold text-on-surface block truncate">Profil Sandwich Generation</span>
                    <span className="text-[10px] text-secondary">Sudah Terpetakan Sempurna</span>
                  </div>
                </div>
                <span className="text-[10px] text-secondary font-bold">Selesai</span>
              </div>

              <div
                onClick={onComplete}
                className="flex items-center justify-between p-3 rounded-xl bg-surface-container-lowest hover:bg-surface transition-colors cursor-pointer group"
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className="w-6 h-6 rounded-full bg-surface-container-high text-primary flex items-center justify-center shrink-0">
                    <span className="material-symbols-outlined text-[14px]">show_chart</span>
                  </div>
                  <div className="min-w-0">
                    <span className="text-xs font-bold text-on-surface block truncate">
                      Cek Simulasi Kebebasan Finansial
                    </span>
                    <span className="text-[10px] text-on-surface-variant">FI Simulator & Target Dana Darurat</span>
                  </div>
                </div>
                <span className="material-symbols-outlined text-primary group-hover:translate-x-0.5 transition-transform text-[16px]">
                  arrow_forward
                </span>
              </div>

              <div
                onClick={onComplete}
                className="flex items-center justify-between p-3 rounded-xl bg-surface-container-lowest hover:bg-surface transition-colors cursor-pointer group"
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className="w-6 h-6 rounded-full bg-surface-container-high text-primary flex items-center justify-center shrink-0">
                    <span className="material-symbols-outlined text-[14px]">smart_toy</span>
                  </div>
                  <div className="min-w-0">
                    <span className="text-xs font-bold text-on-surface block truncate">
                      Konsultasi 1-on-1 dengan Advisor
                    </span>
                    <span className="text-[10px] text-on-surface-variant">Bean Advisor AI Siap Menjawab</span>
                  </div>
                </div>
                <span className="material-symbols-outlined text-primary group-hover:translate-x-0.5 transition-transform text-[16px]">
                  arrow_forward
                </span>
              </div>
            </div>
          </div>

          {/* Primary Hub CTA */}
          <div className="flex flex-col gap-2 pt-1">
            <button
              type="button"
              onClick={onComplete}
              className="w-full py-4 px-6 rounded-full bg-primary text-on-primary font-bold text-sm shadow-lg hover:bg-primary-container active:scale-98 transition-all flex items-center justify-center gap-2"
            >
              <span>Masuk ke Financial Hub</span>
              <span className="material-symbols-outlined text-[20px]">dashboard_customize</span>
            </button>
            <p className="text-center text-[10px] text-outline">
              Privasi dan enkripsi perbankan 256-bit terjaga penuh
            </p>
          </div>
        </div>
      )}

      {/* QR Code Preview Modal */}
      {showQrModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-on-surface/50 backdrop-blur-sm">
          <div className="bg-surface-container-lowest p-6 rounded-2xl max-w-xs w-full flex flex-col items-center text-center shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="flex justify-between w-full items-center mb-3">
              <span className="text-base font-bold text-on-surface">QR Undang Teman</span>
              <button
                type="button"
                onClick={() => setShowQrModal(false)}
                className="text-on-surface-variant hover:text-on-surface"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>

            <div className="p-4 bg-surface rounded-xl shadow-inner mb-3">
              <svg className="w-36 h-36 text-primary" fill="currentColor" viewBox="0 0 100 100">
                <rect height="25" rx="3" width="25" x="5" y="5"></rect>
                <rect fill="#ffffff" height="15" width="15" x="10" y="10"></rect>
                <rect height="9" width="9" x="13" y="13"></rect>
                <rect height="25" rx="3" width="25" x="70" y="5"></rect>
                <rect fill="#ffffff" height="15" width="15" x="75" y="10"></rect>
                <rect height="9" width="9" x="78" y="13"></rect>
                <rect height="25" rx="3" width="25" x="5" y="70"></rect>
                <rect fill="#ffffff" height="15" width="15" x="10" y="75"></rect>
                <rect height="9" width="9" x="13" y="78"></rect>
                <rect height="8" width="8" x="35" y="10"></rect>
                <rect height="6" width="12" x="48" y="15"></rect>
                <rect height="6" width="22" x="38" y="24"></rect>
                <rect fill="#835400" height="24" rx="2" width="30" x="35" y="38"></rect>
                <circle cx="50" cy="50" fill="#ffffff" r="6"></circle>
                <rect height="8" width="16" x="10" y="38"></rect>
                <rect height="12" width="8" x="18" y="52"></rect>
                <rect height="6" width="16" x="74" y="38"></rect>
                <rect height="16" width="10" x="80" y="50"></rect>
                <rect height="12" width="12" x="38" y="70"></rect>
                <rect height="6" width="18" x="56" y="74"></rect>
                <rect height="6" width="24" x="44" y="86"></rect>
                <rect height="12" width="16" x="74" y="80"></rect>
              </svg>
            </div>

            <span className="font-mono font-bold text-primary text-base tracking-wider">SARAH_K7XM2</span>
            <p className="text-xs text-on-surface-variant mt-1">
              Scan melalui kamera smartphone teman untuk bonus registrasi ganda.
            </p>

            <button
              type="button"
              onClick={() => setShowQrModal(false)}
              className="mt-4 w-full py-2.5 rounded-full bg-primary text-on-primary text-xs font-bold"
            >
              Tutup
            </button>
          </div>
        </div>
      )}

      {/* Floating Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-20 inset-x-4 max-w-sm mx-auto z-50 bg-inverse-surface text-inverse-on-surface px-4 py-2.5 rounded-xl shadow-2xl flex items-center gap-2 text-xs font-medium animate-in slide-in-from-bottom-5">
          <span className="material-symbols-outlined text-secondary-fixed text-[18px]">info</span>
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
};
