import React, { useState } from 'react';

export const RewardsTab: React.FC = () => {
  const [points, setPoints] = useState<number>(3450);
  const [quest1Claimed, setQuest1Claimed] = useState<boolean>(false);
  const [toastText, setToastText] = useState<string | null>(null);
  const [redeemedRewards, setRedeemedRewards] = useState<string[]>([]);

  const triggerToast = (msg: string) => {
    setToastText(msg);
    setTimeout(() => setToastText(null), 3000);
  };

  const handleClaimQuest1 = () => {
    if (quest1Claimed) return;
    setQuest1Claimed(true);
    setPoints((prev) => prev + 150);
    triggerToast('Selamat! +150 Bean-Points berhasil diklaim ke saldo.');
  };

  const handleRedeem = (id: string, cost: number, name: string) => {
    if (points < cost) {
      triggerToast('Poin Anda belum mencukupi untuk reward ini.');
      return;
    }
    setPoints((prev) => prev - cost);
    setRedeemedRewards((prev) => [...prev, id]);
    triggerToast(`Sukses menukar ${cost} poin untuk "${name}"! Kode voucher telah dikirim.`);
  };

  const rewards = [
    {
      id: 'prodia',
      title: 'Diskon 25% Fisioterapi & Lab Lansia',
      merchant: 'Klinik Prodia & RS Mitra Keluarga',
      category: 'Kesehatan Ortu',
      points: 800,
      icon: 'medical_services',
    },
    {
      id: 'ruangguru',
      title: 'Subsidi Kursus / Voucher Belajar 1 Bulan',
      merchant: 'Ruangguru & Zenius Premium',
      category: 'Edukasi Anak',
      points: 1200,
      icon: 'school',
    },
    {
      id: 'cfp_session',
      title: 'Sesi Konsultasi Eksklusif CFP 45 Menit',
      merchant: 'Financial Planner Independen',
      category: 'Perencanaan Pensiun',
      points: 1500,
      icon: 'psychology',
    },
    {
      id: 'self_coffee',
      title: 'Voucher Me-Time Kopi & Bakery Rp 50.000',
      merchant: 'Fore Coffee & Tous Les Jours',
      category: 'Self-Care Sandwich',
      points: 350,
      icon: 'coffee',
    },
  ];

  return (
    <div className="max-w-xl mx-auto w-full px-4 pt-2 pb-24 space-y-4">
      {/* 1. Header Section */}
      <section className="flex flex-col space-y-1">
        <div className="flex items-center justify-between">
          <div>
            <span className="inline-flex items-center gap-1 text-primary text-[11px] font-bold uppercase tracking-wider">
              <span className="w-1.5 h-1.5 rounded-full bg-secondary"></span>
              Pencapaian &amp; Loyalitas
            </span>
            <h1 className="text-xl font-bold text-on-surface tracking-tight">Tingkat Sand-Warrior</h1>
          </div>

          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-secondary-fixed text-on-secondary-fixed text-xs font-bold shadow-xs">
            <span className="material-symbols-outlined text-[16px] text-secondary">military_tech</span>
            <span>Level 4: Penjaga Benteng</span>
          </div>
        </div>
      </section>

      {/* 2. Hero Points & Streak Card */}
      <section className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-primary via-primary-container to-secondary-container text-on-primary p-4 shadow-xl">
        <div className="absolute -right-8 -bottom-8 w-36 h-36 rounded-full bg-secondary/20 blur-2xl pointer-events-none"></div>

        <div className="relative z-10 flex flex-col space-y-3">
          <div className="flex items-start justify-between">
            <div className="flex flex-col">
              <span className="text-[11px] uppercase tracking-wider text-primary-fixed-dim font-bold">
                Saldo Bean-Points Anda
              </span>
              <div className="flex items-baseline gap-1.5 mt-0.5">
                <span className="text-3xl font-bold text-surface-bright tracking-tight">
                  {points.toLocaleString('id-ID')}
                </span>
                <span className="text-xs text-secondary-fixed font-bold">Poin</span>
              </div>
            </div>

            <div className="flex flex-col items-end">
              <span className="px-2 py-0.5 rounded-full bg-surface-container-lowest/20 backdrop-blur-md text-secondary-fixed text-[11px] font-bold">
                Bonus 1.5x Aktif
              </span>
              <span className="text-[10px] text-primary-fixed-dim/80 mt-1">Reset: Akhir Tahun</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 pt-1">
            <div className="bg-surface-container-lowest/15 backdrop-blur-md rounded-xl p-2.5 flex flex-col">
              <div className="flex items-center gap-1.5 text-xs text-surface-variant font-medium">
                <span className="material-symbols-outlined text-[16px] text-secondary-fixed">local_fire_department</span>
                <span>Streak Ketahanan</span>
              </div>
              <span className="text-sm font-bold text-on-primary mt-1">42 Hari Rutin</span>
              <span className="text-[10px] text-primary-fixed-dim">Tanpa jebol batas Mo-Pocket</span>
            </div>

            <div className="bg-surface-container-lowest/15 backdrop-blur-md rounded-xl p-2.5 flex flex-col">
              <div className="flex items-center gap-1.5 text-xs text-surface-variant font-medium">
                <span className="material-symbols-outlined text-[16px] text-secondary-fixed">shield</span>
                <span>Tingkat Disiplin</span>
              </div>
              <span className="text-sm font-bold text-on-primary mt-1">94% Sempurna</span>
              <span className="text-[10px] text-primary-fixed-dim">Top 5% Komunitas MOBEAN</span>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Quest Finansial Mingguan */}
      <section className="flex flex-col bg-surface-container-lowest rounded-2xl shadow-sm border border-surface-container-high/60 p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-on-surface">Misi Disiplin Pekanan</h2>
            <p className="text-[11px] text-on-surface-variant">Selesaikan quest untuk menumpuk Bean-Points</p>
          </div>
          <span className="px-2.5 py-0.5 rounded-full bg-surface-container text-primary text-xs font-bold">
            3 Misi Aktif
          </span>
        </div>

        <div className="space-y-2.5">
          {/* Quest 1 */}
          <div className="p-3 rounded-xl bg-surface-container-low border border-surface-container-high/60 flex items-center justify-between gap-3">
            <div className="flex items-start gap-2.5 min-w-0">
              <div className="w-8 h-8 rounded-full bg-secondary-fixed text-on-secondary-fixed flex items-center justify-center shrink-0 mt-0.5">
                <span className="material-symbols-outlined text-[18px]">receipt_long</span>
              </div>
              <div className="flex flex-col min-w-0">
                <span className="text-xs font-bold text-on-surface truncate">Audit Pengeluaran Ortu</span>
                <span className="text-[10px] text-on-surface-variant">
                  Catat 3 transaksi obat &amp; nutrisi (Progress 3/3)
                </span>
                <span className="text-[10px] font-bold text-secondary mt-0.5">+150 Poin</span>
              </div>
            </div>

            <button
              type="button"
              onClick={handleClaimQuest1}
              disabled={quest1Claimed}
              className={`px-3 py-1.5 rounded-full text-xs font-bold shrink-0 transition-transform active:scale-95 ${
                quest1Claimed
                  ? 'bg-surface-container-high text-on-surface-variant cursor-default'
                  : 'bg-primary text-on-primary shadow-xs hover:bg-primary-container'
              }`}
            >
              {quest1Claimed ? 'Telah Diklaim' : 'Klaim Hadiah'}
            </button>
          </div>

          {/* Quest 2 */}
          <div className="p-3 rounded-xl bg-surface-container-low border border-surface-container-high/60 flex items-center justify-between gap-3">
            <div className="flex items-start gap-2.5 min-w-0">
              <div className="w-8 h-8 rounded-full bg-surface-container-high text-primary flex items-center justify-center shrink-0 mt-0.5">
                <span className="material-symbols-outlined text-[18px]">shopping_bag</span>
              </div>
              <div className="flex flex-col min-w-0">
                <span className="text-xs font-bold text-on-surface truncate">Proteksi Portofolio Hobi</span>
                <span className="text-[10px] text-on-surface-variant">
                  Tahan godaan checkout impulsif weekend ini
                </span>
                <span className="text-[10px] font-bold text-secondary mt-0.5">+200 Poin</span>
              </div>
            </div>

            <span className="px-2.5 py-1 rounded-full bg-surface-container text-on-surface-variant text-[11px] font-semibold shrink-0">
              Sedang Aktif
            </span>
          </div>

          {/* Quest 3 */}
          <div className="p-3 rounded-xl bg-surface-container-low border border-surface-container-high/60 flex items-center justify-between gap-3">
            <div className="flex items-start gap-2.5 min-w-0">
              <div className="w-8 h-8 rounded-full bg-surface-container-high text-primary flex items-center justify-center shrink-0 mt-0.5">
                <span className="material-symbols-outlined text-[18px]">tune</span>
              </div>
              <div className="flex flex-col min-w-0">
                <span className="text-xs font-bold text-on-surface truncate">Eksplorasi Simulator FI</span>
                <span className="text-[10px] text-on-surface-variant">
                  Jalankan 1x penyesuaian parameter roadmap pensiun
                </span>
                <span className="text-[10px] font-bold text-secondary mt-0.5">+100 Poin</span>
              </div>
            </div>

            <span className="px-2.5 py-1 rounded-full bg-[#2E6347]/15 text-[#2E6347] text-[11px] font-bold shrink-0 flex items-center gap-0.5">
              <span className="material-symbols-outlined text-[14px]">done</span>
              Selesai
            </span>
          </div>
        </div>
      </section>

      {/* 4. Reward Store (Katalog Manfaat) */}
      <section className="flex flex-col bg-surface-container-lowest rounded-2xl shadow-sm border border-surface-container-high/60 p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-on-surface">Katalog Manfaat Keluarga</h2>
            <p className="text-[11px] text-on-surface-variant">Voucher eksklusif mitra kesehatan, sekolah, &amp; CFP</p>
          </div>
          <span className="text-xs text-primary font-bold">Semua Mitra</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {rewards.map((rw) => {
            const isRedeemed = redeemedRewards.includes(rw.id);

            return (
              <div
                key={rw.id}
                className="p-3.5 rounded-xl bg-surface-container-low border border-surface-container-high/60 flex flex-col justify-between space-y-2.5"
              >
                <div className="flex items-start gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-surface-container-high text-primary flex items-center justify-center shrink-0">
                    <span className="material-symbols-outlined text-[18px]">{rw.icon}</span>
                  </div>
                  <div className="flex flex-col min-w-0">
                    <span className="text-[10px] font-bold uppercase text-secondary tracking-wider">
                      {rw.category}
                    </span>
                    <h3 className="text-xs font-bold text-on-surface leading-snug mt-0.5">
                      {rw.title}
                    </h3>
                    <span className="text-[10px] text-on-surface-variant mt-0.5">{rw.merchant}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-1 border-t border-surface-container-high/60">
                  <span className="text-xs font-bold text-primary flex items-center gap-1">
                    <span className="material-symbols-outlined text-[14px] text-secondary">token</span>
                    {rw.points} Poin
                  </span>

                  <button
                    type="button"
                    onClick={() => handleRedeem(rw.id, rw.points, rw.title)}
                    disabled={isRedeemed || points < rw.points}
                    className={`px-3 py-1 rounded-full text-xs font-bold transition-all ${
                      isRedeemed
                        ? 'bg-surface-container-highest text-on-surface-variant'
                        : points < rw.points
                        ? 'bg-surface-container text-on-surface-variant/40 cursor-not-allowed'
                        : 'bg-primary text-on-primary hover:bg-primary-container active:scale-95 shadow-xs'
                    }`}
                  >
                    {isRedeemed ? 'Tersimpan' : 'Tukar'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Floating Toast */}
      {toastText && (
        <div className="fixed bottom-20 inset-x-4 max-w-sm mx-auto bg-inverse-surface text-inverse-on-surface px-4 py-2.5 rounded-xl shadow-2xl flex items-center gap-2 text-xs font-medium z-50 animate-in slide-in-from-bottom-5">
          <span className="material-symbols-outlined text-secondary-fixed text-[18px]">check_circle</span>
          <span>{toastText}</span>
        </div>
      )}
    </div>
  );
};
