import React, { useState } from 'react';
import { BudgetItem } from '../../types';
import { formatRupiah } from '../../data/mockData';

interface BudgetTabProps {
  budgetItems: BudgetItem[];
  onOpenAddExpense: () => void;
  onOpenCopilot: () => void;
}

export const BudgetTab: React.FC<BudgetTabProps> = ({
  budgetItems,
  onOpenAddExpense,
  onOpenCopilot,
}) => {
  const [period, setPeriod] = useState<'weekly' | 'monthly' | 'quarterly'>('monthly');
  const [isReallocated, setIsReallocated] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [showDeficitModal, setShowDeficitModal] = useState<boolean>(false);

  const totalSpent = budgetItems.reduce((acc, item) => acc + item.spent, 0);
  const totalAllocated = budgetItems.reduce((acc, item) => acc + item.allocated, 0);
  const remaining = totalAllocated - totalSpent;
  const percentUsed = Math.round((totalSpent / totalAllocated) * 100);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleApproveShift = () => {
    setIsReallocated(true);
    showToast('Surplus Rp 850.000 berhasil dialihkan ke Pos Ortu!');
  };

  return (
    <div className="max-w-xl mx-auto w-full px-4 pt-2 pb-24 space-y-4">
      {/* Header Section */}
      <section className="flex flex-col space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <span className="inline-flex items-center gap-1 text-primary text-[11px] font-bold uppercase tracking-wider">
              <span className="w-1.5 h-1.5 rounded-full bg-secondary"></span>
              Perencanaan Cerdas
            </span>
            <h1 className="text-xl font-bold text-on-surface tracking-tight">Alokasi Adaptif Bulanan</h1>
          </div>
          <span className="px-3 py-1 rounded-full bg-surface-container-high text-on-surface-variant text-xs font-semibold">
            Oktober 2024
          </span>
        </div>

        {/* Period Filter Buttons */}
        <div className="flex items-center p-1 bg-surface-container rounded-full w-fit">
          <button
            type="button"
            onClick={() => setPeriod('weekly')}
            className={`px-3.5 py-1 rounded-full text-xs font-semibold transition-all ${
              period === 'weekly'
                ? 'bg-primary text-on-primary shadow-xs'
                : 'text-on-surface-variant hover:text-primary'
            }`}
          >
            Mingguan
          </button>
          <button
            type="button"
            onClick={() => setPeriod('monthly')}
            className={`flex items-center gap-1 px-3.5 py-1 rounded-full text-xs font-semibold transition-all ${
              period === 'monthly'
                ? 'bg-primary text-on-primary shadow-xs'
                : 'text-on-surface-variant hover:text-primary'
            }`}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-secondary-fixed"></span>
            Bulanan
          </button>
          <button
            type="button"
            onClick={() => setPeriod('quarterly')}
            className={`px-3.5 py-1 rounded-full text-xs font-semibold transition-all ${
              period === 'quarterly'
                ? 'bg-primary text-on-primary shadow-xs'
                : 'text-on-surface-variant hover:text-primary'
            }`}
          >
            Kuartalan
          </button>
        </div>

        {/* Overall Budget Summary Card */}
        <div className="p-4 rounded-2xl bg-surface-container-low shadow-sm border border-surface-container-high/60 space-y-2.5">
          <div className="flex justify-between items-start">
            <div>
              <span className="text-[11px] text-on-surface-variant">Realisasi Total Plafon</span>
              <div className="flex items-baseline gap-1 mt-0.5">
                <span className="text-lg font-bold text-primary">{formatRupiah(totalSpent)}</span>
                <span className="text-xs text-on-surface-variant">/ {formatRupiah(totalAllocated)}</span>
              </div>
            </div>
            <div className="text-right">
              <span className="inline-flex items-center px-2 py-0.5 rounded-full bg-surface-container-highest text-primary text-[10px] font-bold">
                11 hari tersisa
              </span>
              <p className="text-xs text-secondary font-bold mt-1">Sisa: {formatRupiah(remaining)}</p>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="space-y-1">
            <div className="w-full h-2.5 rounded-full bg-surface-variant overflow-hidden p-0.5">
              <div
                className="h-full rounded-full bg-gradient-to-r from-primary-container via-primary to-surface-tint transition-all duration-500"
                style={{ width: `${percentUsed}%` }}
              ></div>
            </div>
            <div className="flex justify-between items-center text-on-surface-variant text-[11px]">
              <span>{percentUsed}% terpakai</span>
              <span className="text-secondary font-semibold">Batas aman: 75%</span>
            </div>
          </div>
        </div>
      </section>

      {/* AI Re-allocation Alert Highlight Card */}
      <section className="relative overflow-hidden rounded-2xl bg-primary-container text-on-primary p-4 shadow-md">
        <div className="flex items-center gap-2 mb-2">
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-secondary-fixed text-on-secondary-fixed text-[11px] font-bold">
            <span className="material-symbols-outlined text-[15px] text-secondary">bolt</span>
            Rekomendasi Re-alokasi Adaptif AI
          </span>
        </div>

        <p className="text-xs text-surface-container-low leading-relaxed mt-1">
          Deteksi penghematan! Pos <strong className="text-secondary-fixed">Belanja Hobi</strong> surplus Rp 850.000.
          Sistem merekomendasikan mengalihkan surplus ini ke{' '}
          <strong className="text-secondary-fixed">Pos Kesehatan Ortu</strong> (BPJS &amp; Vitamin Rutin).
        </p>

        {/* Mini Comparison */}
        <div className="flex items-center justify-between p-2.5 my-2.5 rounded-xl bg-primary/40 backdrop-blur-md">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-full bg-surface-container-lowest/10 flex items-center justify-center text-on-primary">
              <span className="material-symbols-outlined text-[16px]">sports_esports</span>
            </div>
            <div className="flex flex-col">
              <span className="text-[10px] text-surface-variant">Belanja Hobi</span>
              <span className="text-xs text-secondary-fixed font-bold">-Rp 850.000</span>
            </div>
          </div>

          <div className="flex items-center justify-center w-6 h-6 rounded-full bg-secondary-fixed text-on-secondary-fixed shadow-xs">
            <span className="material-symbols-outlined text-[16px]">trending_flat</span>
          </div>

          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-full bg-surface-container-lowest/10 flex items-center justify-center text-on-primary">
              <span className="material-symbols-outlined text-[16px]">elderly</span>
            </div>
            <div className="flex flex-col text-right">
              <span className="text-[10px] text-surface-variant">Pos Ortu</span>
              <span className="text-xs text-tertiary-fixed font-bold">+Rp 850.000</span>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2 pt-0.5">
          <button
            type="button"
            onClick={handleApproveShift}
            disabled={isReallocated}
            className={`flex-1 py-2 px-3 rounded-full text-xs font-bold text-center transition-all shadow-sm flex items-center justify-center gap-1 ${
              isReallocated
                ? 'bg-surface-container-lowest text-primary cursor-default'
                : 'bg-secondary-container text-on-secondary-container hover:opacity-90 active:scale-95'
            }`}
          >
            <span className="material-symbols-outlined text-[15px]">
              {isReallocated ? 'check_circle' : 'swap_horiz'}
            </span>
            <span>{isReallocated ? 'Alokasi Telah Dialihkan' : 'Setujui Pengalihan'}</span>
          </button>

          <button
            type="button"
            onClick={() => showToast('Membuka penyesuaian alokasi manual.')}
            className="py-2 px-3 rounded-full bg-surface-container-lowest/15 text-on-primary text-xs font-medium text-center hover:bg-surface-container-lowest/25 transition-all"
          >
            Atur Manual
          </button>
        </div>
      </section>

      {/* 5 Detail Budget Categories */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-on-surface">Alokasi Pilar Sandwich</h2>
          <span className="text-[11px] text-on-surface-variant">5 Kategori Aktif</span>
        </div>

        <div className="space-y-2.5">
          {budgetItems.map((item) => {
            const isOverbudget = item.status === 'OVERBUDGET';
            const pct = Math.min(100, Math.round((item.spent / item.allocated) * 100));

            return (
              <div
                key={item.id}
                className={`p-4 rounded-2xl shadow-xs space-y-2 relative overflow-hidden transition-all border ${
                  isOverbudget
                    ? 'bg-error-container/30 border-error/40'
                    : 'bg-surface-container-lowest border-surface-container-high/60'
                }`}
              >
                {isOverbudget && <div className="absolute left-0 top-0 bottom-0 w-1.5 bg-error"></div>}

                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2.5">
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center shadow-xs ${
                        isOverbudget
                          ? 'bg-error-container text-error'
                          : 'bg-surface-container-high text-primary'
                      }`}
                    >
                      <span className="material-symbols-outlined text-[20px]">{item.icon}</span>
                    </div>
                    <div>
                      <h3 className="text-xs font-bold text-on-surface">{item.title}</h3>
                      <p className="text-[10px] text-on-surface-variant">{item.subtitle}</p>
                    </div>
                  </div>

                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      isOverbudget
                        ? 'bg-error text-on-error'
                        : item.status === 'Tepat Sasaran'
                        ? 'bg-secondary-fixed/50 text-on-secondary-fixed'
                        : 'bg-surface-container-low text-secondary'
                    }`}
                  >
                    {item.status}
                  </span>
                </div>

                <div className="flex justify-between items-baseline pt-0.5">
                  <span
                    className={`text-sm font-bold ${
                      isOverbudget ? 'text-error' : 'text-on-surface'
                    }`}
                  >
                    {formatRupiah(item.spent)}
                  </span>
                  <span className="text-[11px] text-on-surface-variant">
                    Plafon: {formatRupiah(item.allocated)}
                  </span>
                </div>

                <div
                  className={`w-full h-2 rounded-full overflow-hidden ${
                    isOverbudget ? 'bg-error-container' : 'bg-surface-container'
                  }`}
                >
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      isOverbudget ? 'bg-error' : item.id === 'anak' ? 'bg-secondary' : 'bg-primary'
                    }`}
                    style={{ width: `${pct}%` }}
                  ></div>
                </div>

                <div className="flex justify-between text-[10px] text-on-surface-variant">
                  <span className={isOverbudget ? 'text-error font-semibold' : ''}>
                    {isOverbudget
                      ? `110% (Defisit ${formatRupiah(item.spent - item.allocated)})`
                      : `${pct}% terpakai`}
                  </span>
                  <span className={isOverbudget ? 'text-error font-semibold' : ''}>
                    {isOverbudget ? 'Melebihi Limit' : `Sisa ${formatRupiah(Math.max(0, item.allocated - item.spent))}`}
                  </span>
                </div>

                {isOverbudget && (
                  <div className="pt-1">
                    <button
                      type="button"
                      onClick={() => setShowDeficitModal(true)}
                      className="w-full py-2 px-3 rounded-xl bg-error text-on-error text-xs font-bold flex items-center justify-center gap-1.5 shadow-xs hover:opacity-95 transition-opacity"
                    >
                      <span className="material-symbols-outlined text-[16px]">troubleshoot</span>
                      <span>Cari Solusi Defisit</span>
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

      {/* Action Bar */}
      <section className="space-y-2 pt-1">
        <button
          type="button"
          onClick={onOpenAddExpense}
          className="w-full py-3 px-4 rounded-full bg-primary text-on-primary font-bold text-xs flex items-center justify-center gap-2 shadow-md hover:bg-primary-container transition-all active:scale-98"
        >
          <span className="material-symbols-outlined text-[18px]">add_circle</span>
          <span>Catat Pengeluaran Baru</span>
        </button>

        <div className="grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={() => showToast('Laporan portofolio sandwich diunduh sebagai PDF.')}
            className="py-2.5 px-3 rounded-xl bg-surface-container text-on-surface text-xs font-semibold flex items-center justify-center gap-1 hover:bg-surface-container-high transition-colors"
          >
            <span className="material-symbols-outlined text-[16px] text-primary">ios_share</span>
            <span>Export Sandwich</span>
          </button>
          <button
            type="button"
            onClick={() => showToast('Aturan auto-reallocation pintar aktif.')}
            className="py-2.5 px-3 rounded-xl bg-surface-container text-on-surface text-xs font-semibold flex items-center justify-center gap-1 hover:bg-surface-container-high transition-colors"
          >
            <span className="material-symbols-outlined text-[16px] text-secondary">tune</span>
            <span>Atur Rule Otomatis</span>
          </button>
        </div>
      </section>

      {/* Deficit Solution Dialog */}
      {showDeficitModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-on-surface/50 backdrop-blur-sm">
          <div className="bg-surface-container-lowest p-5 rounded-2xl max-w-sm w-full shadow-2xl animate-in zoom-in-95 duration-200 flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-error flex items-center gap-1">
                <span className="material-symbols-outlined text-[18px]">warning</span>
                Solusi Cerdas Defisit Pos Hiburan
              </h3>
              <button
                type="button"
                onClick={() => setShowDeficitModal(false)}
                className="text-on-surface-variant hover:text-primary"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>

            <p className="text-xs text-on-surface-variant leading-relaxed">
              Pos Gaya Hidup terlampaui <strong>Rp 350.000</strong>. Bean Advisor merekomendasikan opsi tanpa memotong tabungan sekolah anak:
            </p>

            <div className="space-y-2 pt-1">
              <button
                type="button"
                onClick={() => {
                  setShowDeficitModal(false);
                  showToast('Defisit ditutup menggunakan sisa kuota Kebutuhan Rumah Tangga.');
                }}
                className="w-full text-left p-3 rounded-xl bg-surface-container-low hover:bg-surface-container border border-surface-container-high flex items-start gap-2.5 transition-colors"
              >
                <span className="material-symbols-outlined text-secondary text-[18px] mt-0.5">swap_calls</span>
                <div className="flex flex-col">
                  <span className="text-xs font-bold text-on-surface">Ambil dari Surplus Rumah Tangga</span>
                  <span className="text-[10px] text-on-surface-variant">Sisa plafon dapur Rp 1.600.000 cukup menutup defisit.</span>
                </div>
              </button>

              <button
                type="button"
                onClick={() => {
                  setShowDeficitModal(false);
                  onOpenCopilot();
                }}
                className="w-full text-left p-3 rounded-xl bg-surface-container-low hover:bg-surface-container border border-surface-container-high flex items-start gap-2.5 transition-colors"
              >
                <span className="material-symbols-outlined text-primary text-[18px] mt-0.5">neurology</span>
                <div className="flex flex-col">
                  <span className="text-xs font-bold text-primary">Konsultasikan ke Bean Advisor AI</span>
                  <span className="text-[10px] text-on-surface-variant">Dapatkan mitigasi cashflow mingguan yang dipersonalisasi.</span>
                </div>
              </button>
            </div>

            <button
              type="button"
              onClick={() => setShowDeficitModal(false)}
              className="mt-2 w-full py-2 rounded-full bg-surface-container-high text-xs font-semibold text-on-surface"
            >
              Tutup
            </button>
          </div>
        </div>
      )}

      {/* Floating Toast */}
      {toastMessage && (
        <div className="fixed bottom-20 inset-x-4 max-w-sm mx-auto bg-inverse-surface text-inverse-on-surface px-4 py-2.5 rounded-xl shadow-2xl flex items-center gap-2 text-xs font-medium z-50 animate-in slide-in-from-bottom-5">
          <span className="material-symbols-outlined text-secondary-fixed text-[18px]">check_circle</span>
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
};
