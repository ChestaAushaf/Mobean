import React, { useState } from 'react';
import { ChatMessage } from '../../types';

interface CopilotTabProps {
  initialMessages: ChatMessage[];
}

export const CopilotTab: React.FC<CopilotTabProps> = ({ initialMessages }) => {
  const [messages, setMessages] = useState<ChatMessage[]>(initialMessages);
  const [inputText, setInputText] = useState<string>('');
  const [isTyping, setIsTyping] = useState<boolean>(false);
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [showHelperBox, setShowHelperBox] = useState<boolean>(false);
  const [toastText, setToastText] = useState<string | null>(null);

  const triggerToast = (msg: string) => {
    setToastText(msg);
    setTimeout(() => setToastText(null), 3000);
  };

  const handleSendMessage = (textToSend: string) => {
    if (!textToSend.trim()) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText('');
    setIsTyping(true);

    // AI intelligent answer generation
    setTimeout(() => {
      setIsTyping(false);
      let replyText = `Berdasarkan kalkulasi profil Prime Sandwich Anda, saya telah menyusun strategi mitigasi tanpa mengorbankan dana pendidikan anak maupun persiapan dana pensiun Anda.`;
      let breakdownData: { badgeNumber: number; title: string; description: string }[] | undefined = undefined;

      const lower = textToSend.toLowerCase();
      if (lower.includes('orang tua') || lower.includes('ortu') || lower.includes('bicara')) {
        replyText = `Membicarakan keuangan dengan orang tua membutuhkan pendekatan empati dan transparansi bertahap.`;
        breakdownData = [
          {
            badgeNumber: 1,
            title: 'Gunakan Pendekatan Solusi & Proteksi',
            description: 'Fokuskan diskusi pada perlindungan kenyamanan dan kesehatan mereka di hari tua, bukan keluhan beban biaya.',
          },
          {
            badgeNumber: 2,
            title: 'Petakan BPJS & Asuransi Aktif',
            description: 'Periksa kembali faskes 1 orang tua agar rujukan rawat jalan dan obat kronis tercover 100%.',
          },
          {
            badgeNumber: 3,
            title: 'Komitmen Pos Terukur',
            description: 'Tetapkan batas Rp 6.250.000/bln yang konsisten, berikan kepastian tanpa kejutan fluktuatif.',
          },
        ];
      } else if (lower.includes('asuransi') || lower.includes('lansia')) {
        replyText = `Berikut opsi perlindungan kesehatan lansia yang paling efisien dari segi rasio premi terhadap manfaat:`;
        breakdownData = [
          {
            badgeNumber: 1,
            title: 'Maksimalkan BPJS Kesehatan Kelas 1',
            description: 'Kombinasi faskes primer terbaik dan obat program rujuk balik (PRB) untuk hipertensi/diabetes.',
          },
          {
            badgeNumber: 2,
            title: 'Asuransi Hospital Cash Plan Mandiri',
            description: 'Menutup biaya transport dan akomodasi pendamping selama rawat inap orang tua.',
          },
        ];
      } else if (lower.includes('lepas') || lower.includes('kapan')) {
        replyText = `Berdasarkan roadmap kemerdekaan finansial Anda, garis akhir sandwich generation Anda diproyeksikan pada usia 48 tahun (Tahun 2032).`;
      }

      const aiMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: 'ai',
        text: replyText,
        timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
        breakdown: breakdownData,
        highlight: 'Kondisi kas keluarga tetap terjaga dalam batas aman likuiditas 5.8 bulan.',
      };

      setMessages((prev) => [...prev, aiMsg]);
    }, 900);
  };

  const promptChips = [
    { emoji: '🌱', text: 'Cara bicara finansial ke orang tua' },
    { emoji: '🛡️', text: 'Asuransi kesehatan murah untuk lansia' },
    { emoji: '📊', text: 'Kapan saya bisa lepas dari sandwich?' },
    { emoji: '💡', text: 'Ide side income untuk keluarga' },
  ];

  return (
    <div className="max-w-xl mx-auto w-full px-4 pt-2 pb-24 flex flex-col space-y-3">
      {/* AI Companion Info Bar */}
      <div className="bg-surface-container-low rounded-2xl p-3.5 shadow-sm border border-surface-container-high/60 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="relative flex items-center justify-center w-10 h-10 rounded-full bg-primary-container text-on-primary">
            <span className="material-symbols-outlined text-[22px]">neurology</span>
            <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-secondary ring-2 ring-surface-container-low"></span>
          </div>
          <div className="flex flex-col min-w-0">
            <div className="flex items-center gap-1">
              <span className="text-sm font-bold text-primary truncate">Bean Advisor AI</span>
              <span className="text-secondary text-xs">✨</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-[#2E6347] animate-pulse"></span>
              <span className="text-[11px] text-on-surface-variant truncate">Online • Spesialis Generasi Sandwich</span>
            </div>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setShowHelperBox(!showHelperBox)}
          className="w-9 h-9 rounded-full bg-surface flex items-center justify-center text-primary hover:bg-surface-container-high transition-colors shadow-xs"
          title="Pengaturan Mode Konsultasi"
        >
          <span className="material-symbols-outlined text-[18px]">tune</span>
        </button>
      </div>

      {/* Real-time Helper Drawer Box */}
      {showHelperBox && (
        <div className="p-3 bg-surface-container-high rounded-xl flex items-center justify-between gap-3 animate-in fade-in">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-secondary text-[20px]">psychology_alt</span>
            <div className="flex flex-col">
              <span className="text-xs font-bold text-on-surface">Mode Empati &amp; Edukasi Aktif</span>
              <span className="text-[10px] text-on-surface-variant">
                Rekomendasi disesuaikan dengan profil 2 tanggungan (1 anak, 1 lansia).
              </span>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setShowHelperBox(false)}
            className="w-6 h-6 rounded-full bg-surface-container flex items-center justify-center text-on-surface-variant"
          >
            <span className="material-symbols-outlined text-[14px]">close</span>
          </button>
        </div>
      )}

      {/* Pinned Daily Recommendation Banner */}
      <div className="relative overflow-hidden bg-gradient-to-br from-primary-container via-primary to-tertiary-container rounded-2xl p-4 text-on-primary shadow-md">
        <div className="absolute -right-6 -bottom-8 w-28 h-28 rounded-full bg-secondary-container/20 blur-xl pointer-events-none"></div>
        <div className="flex items-start justify-between gap-2 mb-1.5">
          <div className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-surface-container-lowest/15 backdrop-blur-md">
            <span className="material-symbols-outlined text-[14px] text-secondary-fixed">push_pin</span>
            <span className="text-[10px] text-secondary-fixed tracking-wide uppercase font-bold">
              Rekomendasi Hari Ini
            </span>
          </div>
          <span className="px-2 py-0.5 rounded-full bg-secondary-fixed/20 text-secondary-fixed text-[10px] font-bold">
            High Impact
          </span>
        </div>

        <h3 className="text-sm font-bold text-on-primary mb-1">
          Optimasi Dana Darurat Bertingkat
        </h3>
        <p className="text-xs text-on-primary/90 leading-relaxed mb-3">
          Simpanan darurat Anda saat ini <strong className="text-secondary-fixed">5.8 bulan</strong> pengeluaran.
          Geser Rp 5.000.000 dari giro ke Reksadana Pasar Uang (yield 5.6%) untuk return ekstra{' '}
          <strong className="text-secondary-fixed">Rp 280.000/th</strong> bebas risiko likuiditas.
        </p>

        <div className="flex items-center gap-2 pt-0.5">
          <button
            type="button"
            onClick={() => {
              handleSendMessage(
                'Tolong jalankan eksekusi otomatis pemindahan dana darurat Rp 5.000.000 ke Reksadana Pasar Uang.'
              );
            }}
            className="flex-1 py-2 px-3 rounded-full bg-secondary-container text-on-secondary-container text-xs font-bold flex items-center justify-center gap-1 shadow-xs active:scale-95 transition-transform"
          >
            <span className="material-symbols-outlined text-[16px]">bolt</span>
            <span>Eksekusi Otomatis</span>
          </button>
          <button
            type="button"
            onClick={() => {
              handleSendMessage(
                'Jelaskan rincian risiko dan proyeksi yield dari Reksadana Pasar Uang yang direkomendasikan.'
              );
            }}
            className="py-2 px-3.5 rounded-full bg-surface/15 hover:bg-surface/25 text-on-primary text-xs font-semibold transition-colors"
          >
            Jelaskan Detail
          </button>
        </div>
      </div>

      {/* Chat Stream */}
      <div className="flex flex-col gap-3.5 pt-1">
        <div className="flex justify-center my-0.5">
          <span className="px-3 py-0.5 rounded-full bg-surface-container-high text-on-surface-variant text-[10px] font-medium">
            Hari Ini, 14:22 WIB
          </span>
        </div>

        {messages.map((msg) => {
          if (msg.sender === 'user') {
            return (
              <div key={msg.id} className="flex justify-end items-end gap-2 pl-8 animate-in fade-in">
                <div className="flex flex-col items-end">
                  <div className="bg-primary text-on-primary rounded-2xl rounded-tr-xs px-4 py-3 shadow-xs max-w-[95%]">
                    <p className="text-xs leading-relaxed">{msg.text}</p>
                  </div>
                  <span className="text-[10px] text-on-surface-variant mt-0.5 mr-1">
                    {msg.timestamp} • Dibaca
                  </span>
                </div>
              </div>
            );
          }

          return (
            <div key={msg.id} className="flex items-start gap-2.5 pr-2 animate-in fade-in">
              <div className="w-8 h-8 rounded-full bg-primary-container text-on-primary flex items-center justify-center shrink-0 shadow-xs mt-1">
                <span className="material-symbols-outlined text-[16px]">spa</span>
              </div>

              <div className="flex flex-col gap-2.5 flex-1 min-w-0">
                <div className="bg-surface-container-lowest text-on-surface rounded-2xl rounded-tl-xs p-4 shadow-sm border border-surface-container-high/60">
                  <div className="flex items-center gap-1.5 mb-2">
                    <span className="text-xs font-bold text-primary">Bean Advisor AI</span>
                    <span className="w-1 h-1 rounded-full bg-outline-variant"></span>
                    <span className="text-[11px] text-on-surface-variant">Solusi Sandwich Terhitung</span>
                  </div>

                  <p className="text-xs text-on-surface mb-2.5 leading-relaxed">{msg.text}</p>

                  {/* Pillars Breakdown */}
                  {msg.breakdown && (
                    <div className="flex flex-col gap-2 mb-2.5">
                      {msg.breakdown.map((item, idx) => (
                        <div
                          key={idx}
                          className="p-2.5 rounded-xl bg-surface-container-low flex items-start gap-2.5 border border-surface-container-high/40"
                        >
                          <div className="w-5 h-5 rounded-full bg-secondary-fixed text-on-secondary-fixed flex items-center justify-center shrink-0 text-[10px] font-bold mt-0.5">
                            {item.badgeNumber || idx + 1}
                          </div>
                          <div className="flex flex-col">
                            <span className="text-xs font-bold text-primary">{item.title}</span>
                            <span className="text-[11px] text-on-surface-variant leading-snug">
                              {item.description}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Highlight Conclusion */}
                  {msg.highlight && (
                    <div className="p-2.5 rounded-xl bg-surface-container-high flex items-center gap-2 text-on-surface">
                      <span className="material-symbols-outlined text-secondary text-[18px] shrink-0">
                        check_circle
                      </span>
                      <span className="text-xs font-medium leading-snug">{msg.highlight}</span>
                    </div>
                  )}

                  {/* In-bubble Actions */}
                  <div className="mt-2.5 flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => triggerToast('Penyesuaian anggaran berhasil diaplikasikan ke Mo-Pocket.')}
                      className="px-3 py-1.5 rounded-full bg-primary-container text-on-primary text-xs font-bold flex items-center gap-1 active:scale-95 transition-transform"
                    >
                      <span className="material-symbols-outlined text-[15px]">sync_saved_locally</span>
                      <span>Terapkan Penyesuaian</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleSendMessage('Bagaimana cara klaim asuransi kesehatan Ibu?')}
                      className="px-3 py-1.5 rounded-full bg-surface-container text-on-surface text-xs font-medium hover:bg-surface-container-high transition-colors"
                    >
                      Bahas Asuransi Ibu
                    </button>
                  </div>
                </div>

                {/* Simulation Card if applicable */}
                {msg.hasSimulationCard && (
                  <div className="bg-surface-container-lowest rounded-2xl p-4 shadow-sm border border-surface-container-high/60">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-1.5">
                        <div className="w-6 h-6 rounded-lg bg-secondary-fixed/50 flex items-center justify-center text-secondary">
                          <span className="material-symbols-outlined text-[15px]">query_stats</span>
                        </div>
                        <span className="text-xs font-bold text-on-surface">Simulasi Dampak Keputusan</span>
                      </div>
                      <span className="px-2 py-0.5 rounded-full bg-surface-container-low text-primary text-[10px] font-bold">
                        On Track
                      </span>
                    </div>

                    <div className="flex flex-col gap-1 mb-2.5">
                      <div className="flex items-center justify-between text-[11px]">
                        <span className="text-on-surface-variant flex items-center gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-primary"></span>
                          Target Tabungan Pensiun Pribadi
                        </span>
                        <span className="font-bold text-primary">98.4% Terjaga</span>
                      </div>
                      <div className="w-full h-2 rounded-full bg-surface-container overflow-hidden">
                        <div
                          className="h-full rounded-full bg-gradient-to-r from-primary to-secondary"
                          style={{ width: '98.4%' }}
                        ></div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div className="p-2.5 rounded-xl bg-surface-container-low flex flex-col">
                        <span className="text-[10px] text-on-surface-variant">Pos Anak Utuh</span>
                        <span className="text-sm font-bold text-on-surface">100%</span>
                        <span className="text-[10px] text-secondary font-semibold">Sesuai rencana les</span>
                      </div>
                      <div className="p-2.5 rounded-xl bg-surface-container-low flex flex-col">
                        <span className="text-[10px] text-on-surface-variant">Beban Ortu Teratasi</span>
                        <span className="text-sm font-bold text-primary">Rp 1.2M</span>
                        <span className="text-[10px] text-on-surface-variant">70% ditanggung klaim</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          );
        })}

        {/* Typing indicator */}
        {isTyping && (
          <div className="flex items-center gap-2 pl-2 text-on-surface-variant text-xs animate-in fade-in">
            <div className="w-6 h-6 rounded-full bg-primary-container text-on-primary flex items-center justify-center shrink-0">
              <span className="material-symbols-outlined text-[13px]">spa</span>
            </div>
            <div className="flex items-center gap-1 bg-surface-container-low px-3 py-1.5 rounded-full">
              <span>Bean AI menghitung opsi terbaik</span>
              <span className="animate-bounce">.</span>
              <span className="animate-bounce" style={{ animationDelay: '0.15s' }}>.</span>
              <span className="animate-bounce" style={{ animationDelay: '0.3s' }}>.</span>
            </div>
          </div>
        )}
      </div>

      {/* Quick Prompt Chips Scroller */}
      <div className="pt-2">
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-[10px] text-on-surface-variant uppercase tracking-wider font-bold">
            Pilihan Pertanyaan Cepat
          </span>
          <span className="text-[10px] text-secondary font-semibold">Geser →</span>
        </div>
        <div className="flex gap-2 overflow-x-auto no-scrollbar py-1">
          {promptChips.map((chip, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => handleSendMessage(chip.text)}
              className="shrink-0 px-3 py-1.5 rounded-full bg-surface-container-low text-primary text-xs font-semibold hover:bg-surface-container-high active:scale-95 transition-all flex items-center gap-1.5 shadow-xs border border-surface-container-high/60"
            >
              <span>{chip.emoji}</span>
              <span>{chip.text}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Chat Input Form */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSendMessage(inputText);
        }}
        className="bg-surface-container-lowest rounded-3xl p-1.5 pl-3 flex items-center gap-2 shadow-md border border-surface-container-high/60"
      >
        <button
          type="button"
          onClick={() => {
            setIsRecording(!isRecording);
            triggerToast(
              isRecording ? 'Perekaman suara selesai.' : 'Mendengarkan suara Anda...'
            );
          }}
          className={`w-9 h-9 rounded-full flex items-center justify-center transition-colors shrink-0 ${
            isRecording
              ? 'bg-error text-on-error animate-pulse'
              : 'bg-surface-container-low text-secondary hover:bg-surface-container-high'
          }`}
          title="Input Suara"
        >
          <span className="material-symbols-outlined text-[18px]">mic</span>
        </button>

        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder={isRecording ? 'Mendengarkan suara Anda...' : 'Ketik pertanyaan finansial keluarga Anda...'}
          className="flex-1 bg-transparent text-xs text-on-surface placeholder:text-on-surface-variant/70 focus:outline-none py-2"
        />

        <button
          type="submit"
          disabled={!inputText.trim()}
          className={`w-9 h-9 rounded-full flex items-center justify-center shadow-xs transition-transform shrink-0 ${
            inputText.trim()
              ? 'bg-primary text-on-primary hover:bg-primary-container active:scale-95'
              : 'bg-surface-container text-on-surface-variant/40 cursor-not-allowed'
          }`}
        >
          <span className="material-symbols-outlined text-[18px]">send</span>
        </button>
      </form>

      <div className="flex items-center justify-center gap-1 text-center">
        <span className="material-symbols-outlined text-[13px] text-on-surface-variant">verified_user</span>
        <p className="text-[10px] text-on-surface-variant">
          Analisis berbasis data kas Anda. Tidak menggantikan penasihat hukum resmi.
        </p>
      </div>

      {/* Floating Toast */}
      {toastText && (
        <div className="fixed bottom-20 inset-x-4 max-w-sm mx-auto bg-inverse-surface text-inverse-on-surface px-4 py-2.5 rounded-xl shadow-2xl flex items-center gap-2 text-xs font-medium z-50 animate-in slide-in-from-bottom-5">
          <span className="material-symbols-outlined text-secondary-fixed text-[18px]">check_circle</span>
          <span>{toastText}</span>
        </div>
      )}
    </div>
  );
};
