import React, { useState } from 'react';
import { BankAccount, MoPocketItem } from '../../types';
import { formatRupiah } from '../../data/mockData';

interface HubTabProps {
  accounts: BankAccount[];
  pockets: MoPocketItem[];
  onOpenBudget: () => void;
  onOpenSimulator: () => void;
  onOpenCopilot: () => void;
}

export const HubTab: React.FC<HubTabProps> = ({
  accounts,
  pockets,
  onOpenBudget,
  onOpenSimulator,
  onOpenCopilot,
}) => {
  const [toastText, setToastText] = useState<string | null>(null);
  const [aiApplied, setAiApplied] = useState<boolean>(false);
  const [showPocketModal, setShowPocketModal] = useState<boolean>(false);
  const [currentPockets, setCurrentPockets] = useState<MoPocketItem[]>(pockets);

  const triggerToast = (msg: string) => {
    setToastText(msg);
    setTimeout(() => setToastText(null), 3500);
  };

  const handleApplyAi = () => {
    setAiApplied(true);
    triggerToast('Surplus Rp 450.000 sukses dipindahkan ke Pos Keluarga & Ortu!');
  };

  const totalBalance = accounts.reduce((sum, acc) => sum + acc.balance, 0);

  return (
    <div className="max-w-xl mx-auto w-full px-4 pt-2 pb-24 space-y-4">
      {/* 1. Warm Welcome Header */}
      <div className="flex items-center justify-between pt-1">
        <div className="min-w-0">
          <div className="flex items-center gap-1.5">
            <h1 className="text-xl font-bold text-on-surface tracking-tight">Halo, Sarah Putri</h1>
            <span className="text-xl inline-block animate-bounce origin-bottom">👋</span>
          </div>
          <div className="flex items-center gap-1.5 mt-0.5">
            <span className="w-2 h-2 rounded-full bg-secondary"></span>
            <p className="text-xs text-on-surface-variant truncate">
              Perjalanan bebas sandwich: <span className="font-semibold text-secondary">On Track!</span>
            </p>
          </div>
        </div>

        <div className="w-10 h-10 rounded-full bg-surface-container-high flex items-center justify-center text-primary shadow-xs">
          <span className="material-symbols-outlined text-[22px]">verified_user</span>
        </div>
      </div>

      {/* 2. Hero Consolidated Wealth Card */}
      <div className="w-full rounded-2xl bg-gradient-to-br from-primary via-primary-container to-tertiary text-on-primary p-4 shadow-xl relative overflow-hidden">
        {/* Ambient organic glow */}
        <div className="absolute -right-12 -top-12 w-44 h-44 rounded-full bg-secondary/20 blur-2xl pointer-events-none"></div>
        <div className="absolute -left-10 -bottom-10 w-36 h-36 rounded-full bg-on-tertiary-container/15 blur-xl pointer-events-none"></div>

        <div className="relative z-10 flex flex-col space-y-3">
          {/* Balance Header & Badge */}
          <div className="flex items-start justify-between">
            <div>
              <span className="text-[11px] uppercase tracking-wider text-primary-fixed-dim font-medium">
                Total Likuiditas Terkonsolidasi
              </span>
              <div className="flex items-baseline gap-1 mt-0.5">
                <span className="text-2xl font-bold tracking-tight text-surface-bright">
                  {formatRupiah(totalBalance)}
                </span>
              </div>
            </div>
            <div className="flex items-center gap-1 bg-surface-container-lowest/15 backdrop-blur-md px-2.5 py-1 rounded-full text-secondary-fixed text-xs font-semibold">
              <span className="material-symbols-outlined text-[14px]">trending_up</span>
              <span>+4.8% bln ini</span>
            </div>
          </div>

          {/* 4 Connected Financial Accounts Grid */}
          <div className="grid grid-cols-2 gap-2 pt-1">
            {accounts.map((acc) => (
              <div
                key={acc.id}
                className="bg-surface-container-lowest/10 backdrop-blur-md rounded-xl p-2.5 flex flex-col justify-between transition-transform active:scale-[0.98] border border-white/10"
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-semibold text-surface-bright/90 truncate">{acc.name}</span>
                  <span className="material-symbols-outlined text-[15px] text-secondary-fixed">
                    {acc.icon}
                  </span>
                </div>
                <p className="text-sm font-bold text-surface-bright tracking-tight">
                  {formatRupiah(acc.balance)}
                </p>
                <span className="text-[10px] text-primary-fixed-dim/80 truncate">{acc.type}</span>
              </div>
            ))}
          </div>

          {/* Card Action Buttons */}
          <div className="flex items-center gap-2 pt-1">
            <button
              type="button"
              onClick={() => triggerToast('Daftar 4 rekening aktif tersinkronisasi aman.')}
              className="flex-1 py-2 rounded-full bg-surface-container-lowest/20 hover:bg-surface-container-lowest/30 text-surface-bright text-xs font-semibold transition-all flex items-center justify-center gap-1"
            >
              <span className="material-symbols-outlined text-[15px]">tune</span>
              <span>Kelola Akun</span>
            </button>
            <button
              type="button"
              onClick={() => triggerToast('Silakan pilih bank untuk menghubungkan akun baru.')}
              className="flex-1 py-2 rounded-full bg-secondary-fixed text-on-secondary-fixed text-xs font-bold transition-all hover:bg-secondary-container flex items-center justify-center gap-1"
            >
              <span className="material-symbols-outlined text-[15px]">add_link</span>
              <span>+ Hubungkan</span>
            </button>
          </div>
        </div>
      </div>

      {/* 3. Financial Health Gauge Card */}
      <div className="w-full bg-surface-container-lowest rounded-2xl p-4 shadow-sm border border-surface-container-high/60">
        <div className="flex items-center justify-between mb-2">
          <div>
            <h2 className="text-base font-bold text-on-surface tracking-tight">Skor Kesehatan Finansial</h2>
            <p className="text-[11px] text-on-surface-variant">Analisis resiliensi multi-generasi</p>
          </div>
          <span className="px-2.5 py-0.5 rounded-full bg-surface-container text-primary text-xs font-semibold flex items-center gap-1">
            <span className="material-symbols-outlined text-[13px]">eco</span>
            <span>Audit Mingguan</span>
          </span>
        </div>

        {/* Gauge Section */}
        <div className="flex flex-col items-center justify-center py-1 relative">
          <div className="relative w-44 h-24 flex items-end justify-center overflow-hidden">
            <svg className="w-44 h-44 -mb-20 transform -rotate-180" viewBox="0 0 100 100">
              <circle
                cx="50"
                cy="50"
                fill="none"
                r="40"
                stroke="#ecdfe2"
                strokeDasharray="125.6 125.6"
                strokeLinecap="round"
                strokeWidth="11"
              ></circle>
              <circle
                cx="50"
                cy="50"
                fill="none"
                r="40"
                stroke="url(#healthGradient)"
                strokeDasharray="98 125.6"
                strokeLinecap="round"
                strokeWidth="11"
              ></circle>
              <defs>
                <linearGradient id="healthGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#4b0015" />
                  <stop offset="60%" stopColor="#835400" />
                  <stop offset="100%" stopColor="#2a7a4c" />
                </linearGradient>
              </defs>
            </svg>

            {/* Score in Center */}
            <div className="absolute inset-x-0 bottom-1 flex flex-col items-center justify-center text-center">
              <div className="flex items-baseline gap-0.5">
                <span className="text-2xl font-bold text-on-surface leading-none">78</span>
                <span className="text-xs text-on-surface-variant font-semibold">/100</span>
              </div>
              <span className="inline-flex items-center gap-1 mt-0.5 px-2 py-0.5 rounded-full bg-surface-container-low text-secondary text-[10px] font-bold">
                Sehat & Berdaya 🌿
              </span>
            </div>
          </div>

          {/* Metrics Breakdown */}
          <div className="w-full grid grid-cols-3 gap-2 mt-3 pt-2 bg-surface-container-low/70 rounded-xl p-2.5">
            <div className="flex flex-col items-center text-center">
              <span className="text-[11px] text-on-surface-variant">Rasio Utang</span>
              <span className="text-xs font-bold text-on-surface mt-0.5">12%</span>
              <span className="text-[10px] text-secondary font-semibold">Rendah</span>
            </div>
            <div className="flex flex-col items-center text-center">
              <span className="text-[11px] text-on-surface-variant">Dana Darurat</span>
              <span className="text-xs font-bold text-on-surface mt-0.5">5.8 bln</span>
              <span className="text-[10px] text-secondary font-semibold">Aman</span>
            </div>
            <div className="flex flex-col items-center text-center">
              <span className="text-[11px] text-on-surface-variant">Support Ortu</span>
              <span className="text-xs font-bold text-on-surface mt-0.5">25%</span>
              <span className="text-[10px] text-secondary font-semibold">Ideal</span>
            </div>
          </div>
        </div>
      </div>

      {/* 4. Sandwich Generation Mo-Pocket */}
      <div className="w-full bg-surface-container-lowest rounded-2xl p-4 shadow-sm border border-surface-container-high/60 space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-on-surface tracking-tight">Mo-Pocket</h2>
            <p className="text-[11px] text-on-surface-variant">Alokasi bulanan beban keluarga & diri</p>
          </div>
          <span className="material-symbols-outlined text-primary text-[22px]">pie_chart</span>
        </div>

        {/* Visual Stacked Bar */}
        <div className="w-full h-3 rounded-full bg-surface-container overflow-hidden flex shadow-inner">
          {currentPockets.map((p) => (
            <div
              key={p.id}
              className={`h-full ${p.color} transition-all`}
              style={{ width: `${p.percentage}%` }}
              title={`${p.name} (${p.percentage}%)`}
            ></div>
          ))}
        </div>

        {/* Pockets List */}
        <div className="space-y-2 pt-1">
          {currentPockets.map((p) => (
            <div
              key={p.id}
              className="flex items-center justify-between p-2.5 rounded-xl bg-surface-container-low hover:bg-surface-container transition-colors"
            >
              <div className="flex items-center gap-2.5">
                <div className={`w-3.5 h-3.5 rounded-full ${p.color} shrink-0`}></div>
                <div>
                  <p className="text-xs font-bold text-on-surface leading-tight">{p.name}</p>
                  <p className="text-[10px] text-on-surface-variant">{p.description}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-xs font-bold text-on-surface">{formatRupiah(p.amount)}</p>
                <span className="text-[11px] font-bold text-primary">{p.percentage}%</span>
              </div>
            </div>
          ))}
        </div>

        {/* Adjust Button */}
        <button
          type="button"
          onClick={() => setShowPocketModal(true)}
          className="w-full py-2.5 rounded-full bg-surface-container-high hover:bg-surface-variant text-primary text-xs font-bold transition-all flex items-center justify-center gap-1.5 active:scale-[0.99]"
        >
          <span className="material-symbols-outlined text-[16px]">tune</span>
          <span>Sesuaikan Alokasi Mo-Pocket</span>
        </button>
      </div>

      {/* 5. Bean Smart Advisor Card */}
      <div className="w-full rounded-2xl bg-surface-container-low p-4 shadow-sm border border-secondary/25 relative overflow-hidden">
        <div className="absolute -right-8 -bottom-8 w-28 h-28 rounded-full bg-secondary-container/20 blur-xl pointer-events-none"></div>
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-secondary text-on-secondary flex items-center justify-center shrink-0 shadow-sm mt-0.5">
            <span className="material-symbols-outlined text-[22px]">auto_awesome</span>
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-primary flex items-center gap-1">
                Bean Smart Advisor
                <span className="w-1.5 h-1.5 rounded-full bg-secondary"></span>
              </span>
              <span className="text-[10px] text-on-surface-variant">Baru saja</span>
            </div>

            <p className="text-xs text-on-surface mt-1.5 leading-relaxed">
              💡 <strong className="text-primary">Analisis MOBEAN:</strong> Surplus Mo-Pocket Gaya Hidup minggu ini
              sebesar <strong className="text-secondary">Rp 450.000</strong> bisa otomatis dialirkan ke{' '}
              <strong className="text-on-surface">Keluarga</strong> tanpa ganggu tabungan anak.
            </p>

            <div className="flex items-center gap-2 mt-3">
              <button
                type="button"
                onClick={handleApplyAi}
                className={`flex-1 py-2 px-3 rounded-full font-bold text-xs shadow-md transition-all flex items-center justify-center gap-1 active:scale-95 ${
                  aiApplied
                    ? 'bg-[#2E6347] text-white'
                    : 'bg-primary text-on-primary hover:bg-primary-container'
                }`}
              >
                <span className="material-symbols-outlined text-[15px]">
                  {aiApplied ? 'done' : 'bolt'}
                </span>
                <span>{aiApplied ? 'Tersimpan!' : 'Terapkan Saran Otomatis'}</span>
              </button>

              <button
                type="button"
                onClick={onOpenCopilot}
                className="py-2 px-3 rounded-full bg-surface-container-lowest text-on-surface-variant hover:text-primary text-xs font-semibold flex items-center justify-center gap-1 shadow-xs"
              >
                <span>Detail</span>
                <span className="material-symbols-outlined text-[14px]">chevron_right</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Adjust Mo-Pocket Modal */}
      {showPocketModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-on-surface/50 backdrop-blur-sm">
          <div className="bg-surface-container-lowest p-5 rounded-2xl max-w-sm w-full shadow-2xl animate-in zoom-in-95 duration-200 flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-primary">Sesuaikan Persentase Mo-Pocket</h3>
              <button
                type="button"
                onClick={() => setShowPocketModal(false)}
                className="text-on-surface-variant hover:text-primary"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>

            <p className="text-xs text-on-surface-variant">
              Total alokasi bulanan: <strong>Rp 25.000.000</strong>. Atur porsi pilar keluarga Anda:
            </p>

            <div className="space-y-3 pt-1">
              {currentPockets.map((p, idx) => (
                <div key={p.id} className="space-y-1">
                  <div className="flex justify-between text-xs font-bold text-on-surface">
                    <span>{p.name}</span>
                    <span>{p.percentage}% ({formatRupiah((25000000 * p.percentage) / 100)})</span>
                  </div>
                  <input
                    type="range"
                    min="10"
                    max="70"
                    step="5"
                    value={p.percentage}
                    onChange={(e) => {
                      const newPct = parseInt(e.target.value, 10);
                      const updated = [...currentPockets];
                      updated[idx].percentage = newPct;
                      updated[idx].amount = (25000000 * newPct) / 100;
                      setCurrentPockets(updated);
                    }}
                    className="w-full accent-primary h-2 bg-surface-container rounded-lg cursor-pointer"
                  />
                </div>
              ))}
            </div>

            <button
              type="button"
              onClick={() => {
                setShowPocketModal(false);
                triggerToast('Alokasi Mo-Pocket berhasil diperbarui!');
              }}
              className="w-full py-2.5 rounded-full bg-primary text-on-primary font-bold text-xs mt-2"
            >
              Simpan Perubahan
            </button>
          </div>
        </div>
      )}

      {/* Toast Notification */}
      {toastText && (
        <div className="fixed bottom-20 inset-x-4 max-w-sm mx-auto bg-inverse-surface text-inverse-on-surface px-4 py-2.5 rounded-xl shadow-2xl flex items-center gap-2 text-xs font-medium z-50 animate-in slide-in-from-bottom-5">
          <span className="material-symbols-outlined text-secondary-fixed text-[18px]">check_circle</span>
          <span>{toastText}</span>
        </div>
      )}
    </div>
  );
};
