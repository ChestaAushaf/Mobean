import React, { useState } from 'react';
import { formatRupiah } from '../../data/mockData';

export const SimulatorTab: React.FC = () => {
  const [monthlyInvestment, setMonthlyInvestment] = useState<number>(6500000);
  const [expectedReturn, setExpectedReturn] = useState<number>(8.5);
  const [postExpenses, setPostExpenses] = useState<number>(12000000);
  const [parentReliefActive, setParentReliefActive] = useState<boolean>(true);
  const [toastText, setToastText] = useState<string | null>(null);

  const resetParams = () => {
    setMonthlyInvestment(6500000);
    setExpectedReturn(8.5);
    setPostExpenses(12000000);
    setParentReliefActive(true);
    triggerToast('Parameter disetel ulang ke default rekomendasi CFP.');
  };

  const triggerToast = (msg: string) => {
    setToastText(msg);
    setTimeout(() => setToastText(null), 4000);
  };

  // Dynamic projection calculations based on sliders
  const yearsToTarget = 8;
  const targetFI = postExpenses * 12 * 25; // 4% rule = 25x annual expenses
  const currentSaved = 1120000000;
  const progressPercent = Math.min(100, Math.round((currentSaved / targetFI) * 100));

  // Dynamic projected amount at age 48
  const calculatedProjectedM = (
    (currentSaved * Math.pow(1 + expectedReturn / 100, yearsToTarget) +
      monthlyInvestment *
        12 *
        ((Math.pow(1 + expectedReturn / 100, yearsToTarget) - 1) / (expectedReturn / 100)) +
      (parentReliefActive ? 2500000 * 12 * 4 : 0)) /
    1000000000
  ).toFixed(1);

  // SVG dynamic curve points
  const curveY48 = Math.max(15, Math.min(65, 80 - parseFloat(calculatedProjectedM) * 11));

  return (
    <div className="max-w-xl mx-auto w-full px-4 pt-2 pb-24 space-y-4">
      {/* 1. Target Banner: Hero Financial Sovereignty Card */}
      <section className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-primary via-primary-container to-tertiary text-on-primary shadow-xl p-4">
        <div className="absolute -right-12 -top-12 w-48 h-48 rounded-full bg-secondary/20 blur-3xl pointer-events-none"></div>
        <div className="absolute -left-10 -bottom-10 w-40 h-40 rounded-full bg-surface-tint/30 blur-2xl pointer-events-none"></div>

        <div className="relative z-10 flex flex-col space-y-3">
          <div className="flex items-start justify-between gap-2">
            <div className="flex flex-col">
              <span className="text-[11px] tracking-wider uppercase text-secondary-fixed font-bold">
                Roadmap Kemerdekaan
              </span>
              <h1 className="text-lg font-bold text-on-primary mt-0.5">Jalur Kebebasan Finansial (FI) Anda</h1>
            </div>
            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-secondary-fixed/20 backdrop-blur-md text-secondary-fixed text-xs font-bold shrink-0">
              <span className="material-symbols-outlined text-[14px]">spa</span>
              8 Thn Lagi
            </span>
          </div>

          <div className="bg-black/25 backdrop-blur-sm rounded-xl p-3 flex flex-col gap-1">
            <div className="flex items-baseline justify-between">
              <span className="text-xs text-surface-variant/90 font-medium">Target FI di Usia 48 Tahun</span>
              <span className="text-xs text-secondary-fixed font-bold">Tahun 2032</span>
            </div>
            <div className="text-2xl font-bold text-on-primary tracking-tight leading-tight flex items-baseline gap-1">
              <span>Rp</span>
              <span>{targetFI.toLocaleString('id-ID')}</span>
            </div>
            <div className="text-[11px] text-surface-variant/90">
              Setara portofolio pasif aman 4% Rule
            </div>
          </div>

          <div className="flex flex-col space-y-1 pt-1">
            <div className="flex justify-between items-baseline">
              <span className="text-xs text-surface-variant">Terkumpul Saat Ini</span>
              <span className="text-xs font-bold text-on-primary">
                {formatRupiah(currentSaved)}{' '}
                <span className="text-secondary-fixed font-normal">({progressPercent}%)</span>
              </span>
            </div>

            <div className="h-2 w-full bg-black/30 rounded-full overflow-hidden p-0.5 flex">
              <div
                className="h-full bg-gradient-to-r from-secondary-fixed-dim to-secondary-container rounded-full transition-all duration-700 ease-out"
                style={{ width: `${progressPercent}%` }}
              ></div>
            </div>

            <div className="flex justify-between items-center text-[10px] text-surface-variant/70 pt-0.5">
              <span>Usia 40 (Sekarang)</span>
              <span>Gap: {formatRupiah(Math.max(0, targetFI - currentSaved))}</span>
              <span>Usia 48 (Merdeka)</span>
            </div>
          </div>
        </div>
      </section>

      {/* 2. Interactive Projection Chart Card */}
      <section className="flex flex-col bg-surface-container-lowest rounded-2xl shadow-sm border border-surface-container-high/60 p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-on-surface">Simulasi Kurva FI Dual-Skenario</h2>
            <p className="text-[11px] text-on-surface-variant">Akselerasi kebebasan melalui alokasi cerdas</p>
          </div>
          <div className="w-8 h-8 rounded-full bg-surface-container flex items-center justify-center text-primary">
            <span className="material-symbols-outlined text-[18px]">insights</span>
          </div>
        </div>

        {/* Chart SVG Visual */}
        <div className="relative w-full bg-surface-container-low rounded-xl p-3 pt-4 overflow-hidden border border-surface-container-high/50">
          <div className="absolute right-2 top-2 px-1.5 py-0.5 rounded bg-surface-container-high/90 text-[10px] text-on-surface-variant font-bold">
            Target: {formatRupiah(targetFI)}
          </div>

          <svg aria-label="Grafik Proyeksi Finansial" className="w-full h-44 overflow-visible" viewBox="0 0 320 180">
            <defs>
              <linearGradient id="maroonGlow" x1="0" x2="0" y1="0" y2="1">
                <stop offset="0%" stopColor="#6a1528" stopOpacity="0.32" />
                <stop offset="100%" stopColor="#6a1528" stopOpacity="0.0" />
              </linearGradient>
              <linearGradient id="conservativeGlow" x1="0" x2="0" y1="0" y2="1">
                <stop offset="0%" stopColor="#887273" stopOpacity="0.1" />
                <stop offset="100%" stopColor="#887273" stopOpacity="0.0" />
              </linearGradient>
            </defs>

            {/* Target Dashed Line */}
            <line opacity="0.8" stroke="#D99B43" strokeDasharray="3,3" strokeWidth="1.2" x1="20" x2="310" y1="35" y2="35" />
            <line opacity="0.4" stroke="#dbc0c2" strokeDasharray="2,2" strokeWidth="0.75" x1="20" x2="310" y1="85" y2="85" />
            <line opacity="0.4" stroke="#dbc0c2" strokeDasharray="2,2" strokeWidth="0.75" x1="20" x2="310" y1="135" y2="135" />

            {/* Conservative Area & Line (Grey Dashed) */}
            <path d="M 20 145 Q 110 135 180 120 T 310 82 L 310 155 L 20 155 Z" fill="url(#conservativeGlow)" />
            <path d="M 20 145 Q 110 135 180 120 T 310 82" fill="none" stroke="#887273" strokeDasharray="5,4" strokeWidth="2" />

            {/* Optimistic MOBEAN Area & Dynamic Line */}
            <path
              d={`M 20 145 Q 90 130 160 95 T 260 ${curveY48} L 310 18 L 310 155 L 20 155 Z`}
              fill="url(#maroonGlow)"
            />
            <path
              d={`M 20 145 Q 90 130 160 95 T 260 ${curveY48} L 310 18`}
              fill="none"
              stroke="#6a1528"
              strokeLinecap="round"
              strokeWidth="3"
            />

            {/* Milestone markers */}
            <circle cx="20" cy="145" fill="#6a1528" r="4" />
            <text fill="#554243" fontSize="9" fontWeight="600" textAnchor="middle" x="20" y="170">
              Usia 40
            </text>

            <line stroke="#dbc0c2" strokeDasharray="2,2" strokeWidth="1" x1="160" x2="160" y1="95" y2="155" />
            <circle cx="160" cy="95" fill="#fcba5f" r="4.5" stroke="#6a1528" strokeWidth="1.5" />
            <text fill="#554243" fontSize="9" fontWeight="600" textAnchor="middle" x="160" y="170">
              Usia 45
            </text>

            <line stroke="#fcba5f" strokeDasharray="2,2" strokeWidth="1.5" x1="260" x2="260" y1={curveY48} y2="155" />
            <circle cx="260" cy={curveY48} fill="#835400" r="6" />
            <circle cx="260" cy={curveY48} fill="#ffffff" r="3" />
            <text fill="#4b0015" fontSize="9" fontWeight="700" textAnchor="middle" x="260" y="170">
              Usia 48 🎯
            </text>

            <circle cx="310" cy="82" fill="#887273" r="3.5" />
            <text fill="#887273" fontSize="8" textAnchor="end" x="305" y="170">
              Usia 56
            </text>
          </svg>
        </div>

        {/* Legend & Summary Cards */}
        <div className="grid grid-cols-2 gap-2 pt-1">
          <div className="flex flex-col p-2.5 rounded-xl bg-surface-container-low border border-surface-container-high/60">
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-1 rounded-full bg-primary-container"></span>
              <span className="text-[11px] font-bold text-primary">Skenario MOBEAN</span>
            </div>
            <span className="text-base font-bold text-on-surface mt-1">Rp {calculatedProjectedM} M</span>
            <span className="text-[10px] text-secondary font-bold">Bebas di usia 48 thn ✨</span>
          </div>

          <div className="flex flex-col p-2.5 rounded-xl bg-surface-container border border-surface-container-high/60">
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-0.5 border-t border-dashed border-outline"></span>
              <span className="text-[11px] font-medium text-on-surface-variant">Tanpa Optimasi</span>
            </div>
            <span className="text-base font-bold text-on-surface-variant mt-1">Rp 2.9 M</span>
            <span className="text-[10px] text-outline font-medium">Bebas di usia 56 thn (+8 thn)</span>
          </div>
        </div>
      </section>

      {/* 3. Interactive Simulator Sliders */}
      <section className="flex flex-col bg-surface-container-lowest rounded-2xl shadow-sm border border-surface-container-high/60 p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-on-surface">Variabel Portofolio</h2>
            <p className="text-[11px] text-on-surface-variant">Ubah parameter untuk menguji ketahanan simulasi</p>
          </div>
          <button
            type="button"
            onClick={resetParams}
            className="flex items-center gap-1 text-primary hover:text-primary-container text-xs font-semibold"
          >
            <span className="material-symbols-outlined text-[16px]">refresh</span>
            <span>Reset</span>
          </button>
        </div>

        {/* Slider 1 */}
        <div className="flex flex-col space-y-1.5 p-3 rounded-xl bg-surface-container-low border border-surface-container-high/60">
          <div className="flex justify-between items-baseline">
            <label className="text-xs font-bold text-on-surface">Kontribusi Investasi Bulanan</label>
            <span className="text-xs font-bold text-primary">{formatRupiah(monthlyInvestment)}</span>
          </div>
          <input
            type="range"
            min={2000000}
            max={15000000}
            step={500000}
            value={monthlyInvestment}
            onChange={(e) => setMonthlyInvestment(Number(e.target.value))}
            className="w-full h-2 bg-surface-container-highest rounded-lg appearance-none cursor-pointer accent-primary"
          />
          <div className="flex justify-between text-[10px] text-on-surface-variant font-medium">
            <span>Rp 2 Juta</span>
            <span className="text-secondary font-bold">Rekomendasi: 35% Gaji</span>
            <span>Rp 15 Juta</span>
          </div>
        </div>

        {/* Slider 2 */}
        <div className="flex flex-col space-y-1.5 p-3 rounded-xl bg-surface-container-low border border-surface-container-high/60">
          <div className="flex justify-between items-baseline">
            <label className="text-xs font-bold text-on-surface">Ekspektasi Return Portofolio</label>
            <span className="text-xs font-bold text-primary">{expectedReturn.toFixed(1)}% p.a.</span>
          </div>
          <input
            type="range"
            min={5.0}
            max={14.0}
            step={0.25}
            value={expectedReturn}
            onChange={(e) => setExpectedReturn(parseFloat(e.target.value))}
            className="w-full h-2 bg-surface-container-highest rounded-lg appearance-none cursor-pointer accent-primary"
          />
          <div className="flex justify-between text-[10px] text-on-surface-variant font-medium">
            <span>5.0% (Konservatif)</span>
            <span className="text-secondary font-bold">Index &amp; Obligasi</span>
            <span>14.0% (Agresif)</span>
          </div>
        </div>

        {/* Slider 3 */}
        <div className="flex flex-col space-y-1.5 p-3 rounded-xl bg-surface-container-low border border-surface-container-high/60">
          <div className="flex justify-between items-baseline">
            <label className="text-xs font-bold text-on-surface">Biaya Hidup Pasca-Pensiun</label>
            <span className="text-xs font-bold text-primary">{formatRupiah(postExpenses)}</span>
          </div>
          <input
            type="range"
            min={7000000}
            max={25000000}
            step={500000}
            value={postExpenses}
            onChange={(e) => setPostExpenses(Number(e.target.value))}
            className="w-full h-2 bg-surface-container-highest rounded-lg appearance-none cursor-pointer accent-primary"
          />
          <div className="flex justify-between text-[10px] text-on-surface-variant font-medium">
            <span>Rp 7 Juta/bln</span>
            <span className="text-secondary font-bold">Asumsi Bebas Utang</span>
            <span>Rp 25 Juta/bln</span>
          </div>
        </div>
      </section>

      {/* 4. Toggle Beban Ortu */}
      <section className="flex flex-col bg-surface-container-low rounded-2xl p-4 shadow-sm border border-surface-container-high/60 space-y-2.5">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-full bg-secondary-fixed flex items-center justify-center text-on-secondary-fixed shrink-0">
              <span className="material-symbols-outlined text-[20px]">family_restroom</span>
            </div>
            <div className="flex flex-col">
              <span className="text-xs font-bold text-on-surface">Pengurangan Beban Tanggungan Ortu</span>
              <p className="text-[11px] text-on-surface-variant mt-0.5 leading-snug">
                Aktifkan Pengurangan Beban Ortu (Asuransi Pensiun Mandiri Ortu Mulai Cair di Usia 52)
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setParentReliefActive(!parentReliefActive)}
            className={`w-12 h-6 rounded-full transition-colors relative flex items-center p-0.5 shrink-0 mt-1 ${
              parentReliefActive ? 'bg-primary' : 'bg-surface-container-highest'
            }`}
          >
            <div
              className={`w-5 h-5 rounded-full bg-white transition-transform ${
                parentReliefActive ? 'translate-x-6' : 'translate-x-0'
              }`}
            ></div>
          </button>
        </div>

        {parentReliefActive && (
          <div className="flex items-center gap-2 p-2.5 rounded-xl bg-surface-container-lowest text-secondary shadow-xs animate-in fade-in">
            <span className="material-symbols-outlined text-[18px] text-secondary shrink-0">
              trending_up
            </span>
            <span className="text-xs font-bold leading-tight">
              +Rp 2.500.000/bln kapasitas investasi bertambah otomatis saat beban berkurang di usia 44!
            </span>
          </div>
        )}
      </section>

      {/* 5. 3 Life Milestones */}
      <section className="flex flex-col bg-surface-container-lowest rounded-2xl shadow-sm border border-surface-container-high/60 p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-on-surface">3 Milestone Hidup Sandwich</h2>
            <p className="text-[11px] text-on-surface-variant">Titik kritis sinkronisasi keluarga & kemerdekaan</p>
          </div>
          <span className="px-2.5 py-0.5 rounded-full bg-secondary-fixed/50 text-on-secondary-fixed text-[10px] font-bold">
            Terjadwal
          </span>
        </div>

        <div className="relative flex flex-col space-y-3 pl-2">
          {/* Vertical line */}
          <div className="absolute left-5 top-4 bottom-4 w-0.5 bg-surface-variant"></div>

          {/* Milestone 1 */}
          <div className="relative flex items-start gap-3">
            <div className="relative z-10 w-7 h-7 rounded-full bg-primary text-on-primary flex items-center justify-center text-xs font-bold shadow-xs shrink-0">
              1
            </div>
            <div className="flex-1 p-3 rounded-xl bg-surface-container-low border border-surface-container-high/60">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-on-surface">🎓 Kuliah Anak Pertama (PTN)</span>
                <span className="px-2 py-0.5 rounded-full bg-secondary-fixed text-on-secondary-fixed text-[10px] font-bold">
                  44Thn
                </span>
              </div>
              <p className="text-[11px] text-on-surface-variant mt-1 leading-snug">
                Target biaya semester & UKT 8 semester tersimpan di instrumen terpisah.
              </p>
              <div className="flex items-center gap-2 mt-2">
                <div className="h-1.5 flex-1 bg-surface-variant rounded-full overflow-hidden">
                  <div className="h-full bg-secondary rounded-full" style={{ width: '85%' }}></div>
                </div>
                <span className="text-[10px] font-bold text-secondary shrink-0">Dana Siap 85%</span>
              </div>
            </div>
          </div>

          {/* Milestone 2 */}
          <div className="relative flex items-start gap-3">
            <div className="relative z-10 w-7 h-7 rounded-full bg-primary text-on-primary flex items-center justify-center text-xs font-bold shadow-xs shrink-0">
              2
            </div>
            <div className="flex-1 p-3 rounded-xl bg-surface-container-low border border-surface-container-high/60">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-on-surface">🏡 Pelunasan KPR Rumah</span>
                <span className="px-2 py-0.5 rounded-full bg-secondary-fixed text-on-secondary-fixed text-[10px] font-bold">
                  46Thn
                </span>
              </div>
              <p className="text-[11px] text-on-surface-variant mt-1 leading-snug">
                Beban cicilan bulanan sebesar Rp 5.8 Juta/bulan berakhir sepenuhnya.
              </p>
              <div className="inline-flex items-center gap-1.5 mt-2 text-on-surface-variant text-[10px]">
                <span className="material-symbols-outlined text-[14px] text-secondary">schedule</span>
                <span>
                  Tersisa <strong className="text-on-surface">32 cicilan</strong> pembayaran reguler
                </span>
              </div>
            </div>
          </div>

          {/* Milestone 3 */}
          <div className="relative flex items-start gap-3">
            <div className="relative z-10 w-7 h-7 rounded-full bg-secondary text-on-secondary flex items-center justify-center text-xs font-bold shadow-xs ring-2 ring-secondary-container shrink-0">
              <span className="material-symbols-outlined text-[14px]">celebration</span>
            </div>
            <div className="flex-1 p-3 rounded-xl bg-primary-container text-on-primary shadow-xs">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-on-primary">🕊️ Sandwich Exit &amp; Kebebasan</span>
                <span className="px-2 py-0.5 rounded-full bg-secondary-fixed text-on-secondary-fixed text-[10px] font-bold">
                  48Thn
                </span>
              </div>
              <p className="text-[11px] text-surface-variant/90 mt-1 leading-snug">
                Kemandirian total tercapai. Bekerja hanya untuk aktualisasi diri.
              </p>
              <div className="mt-2 pt-2 border-t border-white/10 flex items-center justify-between text-[11px]">
                <span className="text-secondary-fixed">Portofolio Pasif Income</span>
                <span className="font-bold text-on-primary">Rp 16.000.000 / bln</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 6. CFP Consultation Advisory Banner */}
      <section className="relative overflow-hidden rounded-2xl bg-surface-container p-4 shadow-sm border border-surface-container-high/60">
        <div className="flex flex-col space-y-3 relative z-10">
          <div className="flex items-start gap-3">
            <div className="w-12 h-12 rounded-full overflow-hidden shrink-0 shadow-sm bg-surface ring-1 ring-secondary/30">
              <img
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuBKTTz448RlVEuTrN5QGalGaWzmE5gmU-IvtpuF6mjS97R7Bh2SnXzDyeDuiv1EVQSWeL4p_OzKEuiivlGPZBNfc4YBLZpdsY5d8rl44h1cgLmNVhnscHEv7Mm1QmOgMbX8b37Cxpiw_DED8rDHPr3PDsRUOWSEvDc5dBfN7jEk54WGOoENzf2GrtxA9uZFUN0iyHwvtlagCTaOYgqBk3w-V1qT3YNa5pd0wXBxPBw3744oq4MT77Qg"
                alt="CFP Advisor"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="flex flex-col">
              <div className="inline-flex items-center gap-1 text-secondary text-[10px] font-bold uppercase">
                <span className="material-symbols-outlined text-[14px]">verified</span>
                Saran Ahli Tersertifikasi
              </div>
              <h3 className="text-sm font-bold text-on-surface mt-0.5">
                Butuh Validasi Rencana Bebas Finansial?
              </h3>
            </div>
          </div>

          <p className="text-xs text-on-surface-variant leading-relaxed">
            Konsultasikan roadmap simulasi ini dengan CFP berlisensi spesialis Keuangan Sandwich. Hindari jebakan likuiditas saat anak kuliah &amp; ortu pensiun bersamaan.
          </p>

          <div className="flex flex-col sm:flex-row gap-2 pt-1">
            <button
              type="button"
              onClick={() =>
                triggerToast('Slot Gratis Berhasil Diamankan! Tim CFP MOBEAN akan menghubungi lewat WhatsApp.')
              }
              className="flex-1 py-3 px-4 rounded-full bg-primary hover:bg-primary-container text-on-primary text-xs font-bold flex items-center justify-center gap-1.5 shadow-md active:scale-98 transition-all"
            >
              <span className="material-symbols-outlined text-[16px]">calendar_month</span>
              <span>Booking Sesi CFP (Gratis 1x)</span>
            </button>
            <button
              type="button"
              onClick={() => triggerToast('Membuka profil Certified Financial Planner (CFP).')}
              className="py-3 px-4 rounded-full bg-surface-container-lowest text-primary text-xs font-bold flex items-center justify-center shadow-xs hover:bg-surface-container transition-colors"
            >
              Lihat Profil CFP
            </button>
          </div>
        </div>
      </section>

      {/* Toast */}
      {toastText && (
        <div className="fixed bottom-20 inset-x-4 max-w-sm mx-auto bg-inverse-surface text-inverse-on-surface px-4 py-2.5 rounded-xl shadow-2xl flex items-center gap-2 text-xs font-medium z-50 animate-in slide-in-from-bottom-5">
          <span className="material-symbols-outlined text-secondary-fixed text-[18px]">check_circle</span>
          <span>{toastText}</span>
        </div>
      )}
    </div>
  );
};
