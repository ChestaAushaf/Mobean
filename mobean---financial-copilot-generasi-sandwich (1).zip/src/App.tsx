/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ActiveTab, BankAccount, MoPocketItem, BudgetItem, ChatMessage } from './types';
import {
  INITIAL_BANK_ACCOUNTS,
  INITIAL_MO_POCKETS,
  INITIAL_BUDGET_ITEMS,
  INITIAL_CHAT_MESSAGES,
} from './data/mockData';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { RegistrationWizard } from './components/onboarding/RegistrationWizard';
import { HubTab } from './components/tabs/HubTab';
import { BudgetTab } from './components/tabs/BudgetTab';
import { SimulatorTab } from './components/tabs/SimulatorTab';
import { CopilotTab } from './components/tabs/CopilotTab';
import { RewardsTab } from './components/tabs/RewardsTab';
import { ExpenseModal } from './components/ExpenseModal';

export default function App() {
  const [viewMode, setViewMode] = useState<'app' | 'onboarding'>('onboarding');
  const [activeTab, setActiveTab] = useState<ActiveTab>('hub');

  // Application Dynamic State
  const [accounts] = useState<BankAccount[]>(INITIAL_BANK_ACCOUNTS);
  const [pockets] = useState<MoPocketItem[]>(INITIAL_MO_POCKETS);
  const [budgetItems, setBudgetItems] = useState<BudgetItem[]>(INITIAL_BUDGET_ITEMS);
  const [chatMessages] = useState<ChatMessage[]>(INITIAL_CHAT_MESSAGES);

  // Modals & Drawers
  const [isExpenseModalOpen, setIsExpenseModalOpen] = useState<boolean>(false);
  const [showNotificationDrawer, setShowNotificationDrawer] = useState<boolean>(false);
  const [showProfileDrawer, setShowProfileDrawer] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleAddExpense = (categoryId: string, amount: number, description: string) => {
    setBudgetItems((prev) =>
      prev.map((item) => {
        if (item.id === categoryId) {
          const newSpent = item.spent + amount;
          const isOver = newSpent > item.allocated;
          return {
            ...item,
            spent: newSpent,
            status: isOver ? 'OVERBUDGET' : item.status === 'Tepat Sasaran' ? 'Tepat Sasaran' : 'Aman',
          };
        }
        return item;
      })
    );
    triggerToast(`Pengeluaran Rp ${amount.toLocaleString('id-ID')} ("${description}") berhasil dicatat!`);
  };

  return (
    <div className="min-h-screen bg-surface flex flex-col font-sans text-on-surface antialiased selection:bg-secondary-fixed selection:text-on-secondary-fixed">
      {/* Top Application Header */}
      <Header
        currentTab={activeTab}
        viewMode={viewMode}
        onToggleViewMode={() => setViewMode(viewMode === 'app' ? 'onboarding' : 'app')}
        onNotificationClick={() => setShowNotificationDrawer(true)}
        onProfileClick={() => setShowProfileDrawer(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 w-full flex flex-col relative overflow-y-auto pt-16">
        {viewMode === 'onboarding' ? (
          <RegistrationWizard
            onComplete={() => {
              setViewMode('app');
              setActiveTab('hub');
              triggerToast('Selamat datang di MOBEAN! Akun dan data finansial Anda telah siap.');
            }}
            onBackToApp={() => setViewMode('app')}
          />
        ) : (
          <div className="flex-1 w-full">
            {activeTab === 'hub' && (
              <HubTab
                accounts={accounts}
                pockets={pockets}
                onOpenBudget={() => setActiveTab('budget')}
                onOpenSimulator={() => setActiveTab('simulator')}
                onOpenCopilot={() => setActiveTab('copilot')}
              />
            )}

            {activeTab === 'budget' && (
              <BudgetTab
                budgetItems={budgetItems}
                onOpenAddExpense={() => setIsExpenseModalOpen(true)}
                onOpenCopilot={() => setActiveTab('copilot')}
              />
            )}

            {activeTab === 'simulator' && <SimulatorTab />}

            {activeTab === 'copilot' && <CopilotTab initialMessages={chatMessages} />}

            {activeTab === 'rewards' && <RewardsTab />}
          </div>
        )}
      </main>

      {/* Bottom Floating Navigation (Visible when in app view) */}
      {viewMode === 'app' && (
        <BottomNav currentTab={activeTab} onTabChange={(tab) => setActiveTab(tab)} />
      )}

      {/* Add Expense Modal */}
      <ExpenseModal
        isOpen={isExpenseModalOpen}
        onClose={() => setIsExpenseModalOpen(false)}
        categories={budgetItems}
        onAddExpense={handleAddExpense}
      />

      {/* Notifications Drawer */}
      {showNotificationDrawer && (
        <div className="fixed inset-0 z-50 flex justify-end bg-on-surface/40 backdrop-blur-xs animate-in fade-in">
          <div className="bg-surface-container-lowest w-full max-w-sm h-full p-4 flex flex-col shadow-2xl animate-in slide-in-from-right duration-300">
            <div className="flex items-center justify-between pb-3 border-b border-surface-container-high">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-primary text-[20px]">notifications</span>
                <h3 className="text-sm font-bold text-on-surface">Notifikasi Finansial</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowNotificationDrawer(false)}
                className="w-7 h-7 rounded-full bg-surface-container flex items-center justify-center text-on-surface-variant hover:text-on-surface"
              >
                <span className="material-symbols-outlined text-[16px]">close</span>
              </button>
            </div>

            <div className="flex-1 overflow-y-auto space-y-2.5 py-3">
              <div className="p-3 rounded-xl bg-surface-container-low border border-secondary/20">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-secondary uppercase">Bean Smart Advisor</span>
                  <span className="text-[10px] text-on-surface-variant">10 mnt lalu</span>
                </div>
                <p className="text-xs font-bold text-on-surface mt-1">Surplus Pos Gaya Hidup</p>
                <p className="text-[11px] text-on-surface-variant mt-0.5">
                  Ada surplus Rp 450.000 yang bisa dialihkan ke pos orang tua.
                </p>
              </div>

              <div className="p-3 rounded-xl bg-surface-container-low border border-surface-container-high">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-primary uppercase">Sinkronisasi Bank</span>
                  <span className="text-[10px] text-on-surface-variant">1 jam lalu</span>
                </div>
                <p className="text-xs font-bold text-on-surface mt-1">4 Rekening Tersambung Aman</p>
                <p className="text-[11px] text-on-surface-variant mt-0.5">
                  BCA, Mandiri, GoPay, dan Bibit telah memperbarui mutasi otomatis.
                </p>
              </div>

              <div className="p-3 rounded-xl bg-surface-container-low border border-surface-container-high">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-secondary uppercase">Loyalitas Poin</span>
                  <span className="text-[10px] text-on-surface-variant">Kemarin</span>
                </div>
                <p className="text-xs font-bold text-on-surface mt-1">+150 Bean-Points Tersedia</p>
                <p className="text-[11px] text-on-surface-variant mt-0.5">
                  Misi audit pengeluaran obat ortu telah selesai dicatat.
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                setShowNotificationDrawer(false);
                triggerToast('Semua notifikasi telah ditandai terbaca.');
              }}
              className="w-full py-2.5 rounded-full bg-primary text-on-primary font-bold text-xs shadow-xs"
            >
              Tandai Semua Dibaca
            </button>
          </div>
        </div>
      )}

      {/* Profile & Security Drawer */}
      {showProfileDrawer && (
        <div className="fixed inset-0 z-50 flex justify-end bg-on-surface/40 backdrop-blur-xs animate-in fade-in">
          <div className="bg-surface-container-lowest w-full max-w-sm h-full p-4 flex flex-col shadow-2xl animate-in slide-in-from-right duration-300">
            <div className="flex items-center justify-between pb-3 border-b border-surface-container-high">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-primary text-[20px]">account_circle</span>
                <h3 className="text-sm font-bold text-on-surface">Profil Pengguna</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowProfileDrawer(false)}
                className="w-7 h-7 rounded-full bg-surface-container flex items-center justify-center text-on-surface-variant hover:text-on-surface"
              >
                <span className="material-symbols-outlined text-[16px]">close</span>
              </button>
            </div>

            <div className="flex-1 overflow-y-auto space-y-4 py-3">
              <div className="flex items-center gap-3 p-3 rounded-xl bg-surface-container-low border border-surface-container-high">
                <img
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuDFc1qWk_d3k4d5_54gR0D-X781Z3962FpE_iUa1uN4eQfVp19n7d8002vQpYxN3nQ76w"
                  alt="Sarah Putri"
                  className="w-12 h-12 rounded-full object-cover ring-2 ring-primary"
                  onError={(e) => {
                    e.currentTarget.src =
                      'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80';
                  }}
                />
                <div>
                  <h4 className="text-sm font-bold text-on-surface">Sarah Putri, S.E.</h4>
                  <p className="text-xs text-on-surface-variant">sarah.putri@mobean.id</p>
                  <span className="inline-block mt-1 px-2 py-0.5 rounded-full bg-secondary-fixed text-on-secondary-fixed text-[10px] font-bold">
                    Prime Sandwich Warrior
                  </span>
                </div>
              </div>

              <div className="space-y-2">
                <span className="text-[10px] font-bold uppercase text-on-surface-variant tracking-wider">
                  Pengaturan &amp; Onboarding
                </span>

                <button
                  type="button"
                  onClick={() => {
                    setShowProfileDrawer(false);
                    setViewMode('onboarding');
                  }}
                  className="w-full text-left p-2.5 rounded-xl bg-surface-container hover:bg-surface-container-high flex items-center justify-between text-xs font-semibold text-primary transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <span className="material-symbols-outlined text-[18px]">how_to_reg</span>
                    <span>Buka Wizard Registrasi 6 Langkah</span>
                  </div>
                  <span className="material-symbols-outlined text-[16px]">chevron_right</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    triggerToast('Enkripsi AES-256 dan sertifikasi OJK Bank aktif.');
                  }}
                  className="w-full text-left p-2.5 rounded-xl bg-surface-container hover:bg-surface-container-high flex items-center justify-between text-xs font-semibold text-on-surface transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <span className="material-symbols-outlined text-[18px] text-secondary">security</span>
                    <span>Keamanan &amp; Enkripsi Biometrik</span>
                  </div>
                  <span className="material-symbols-outlined text-[16px]">chevron_right</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    triggerToast('Bantuan WhatsApp Official MOBEAN: +62 811-MOBEAN.');
                  }}
                  className="w-full text-left p-2.5 rounded-xl bg-surface-container hover:bg-surface-container-high flex items-center justify-between text-xs font-semibold text-on-surface transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <span className="material-symbols-outlined text-[18px] text-primary">support_agent</span>
                    <span>Bantuan CFP &amp; Customer Care</span>
                  </div>
                  <span className="material-symbols-outlined text-[16px]">chevron_right</span>
                </button>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                setShowProfileDrawer(false);
                triggerToast('Sesi Sarah Putri telah diamankan.');
              }}
              className="w-full py-2.5 rounded-full bg-surface-container-high text-on-surface font-bold text-xs"
            >
              Tutup Profil
            </button>
          </div>
        </div>
      )}

      {/* Global Toast Message */}
      {toastMessage && (
        <div className="fixed bottom-20 inset-x-4 max-w-sm mx-auto bg-inverse-surface text-inverse-on-surface px-4 py-2.5 rounded-xl shadow-2xl flex items-center gap-2 text-xs font-medium z-50 animate-in slide-in-from-bottom-5">
          <span className="material-symbols-outlined text-secondary-fixed text-[18px]">check_circle</span>
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
