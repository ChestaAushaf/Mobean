export type ActiveTab = 'hub' | 'budget' | 'simulator' | 'copilot' | 'rewards';
export type AppViewMode = 'app' | 'onboarding';

export interface BankAccount {
  id: string;
  name: string;
  type: string;
  balance: number;
  icon: string;
  badge?: string;
  connected: boolean;
}

export interface MoPocketItem {
  id: string;
  name: string;
  description: string;
  amount: number;
  percentage: number;
  color: string;
}

export interface BudgetItem {
  id: string;
  title: string;
  subtitle: string;
  spent: number;
  allocated: number;
  status: 'Aman' | 'Tepat Sasaran' | 'Terkendali' | 'OVERBUDGET' | 'Terpenuhi';
  icon: string;
  accentColor: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
  breakdown?: {
    title: string;
    description: string;
    badgeNumber?: number;
  }[];
  highlight?: string;
  hasSimulationCard?: boolean;
}
