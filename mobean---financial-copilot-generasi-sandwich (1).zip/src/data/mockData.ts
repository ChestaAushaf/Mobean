import { BankAccount, MoPocketItem, BudgetItem, ChatMessage } from '../types';

export const INITIAL_BANK_ACCOUNTS: BankAccount[] = [
  {
    id: 'bca',
    name: 'BCA Priority',
    type: 'Operasional Utama',
    balance: 68200000,
    icon: 'account_balance',
    badge: 'Tersambung (Utama)',
    connected: true,
  },
  {
    id: 'mandiri',
    name: 'Bank Mandiri',
    type: 'Keluarga & Ortu',
    balance: 32150000,
    icon: 'volunteer_activism',
    badge: 'Auto-sync',
    connected: true,
  },
  {
    id: 'gopay',
    name: 'GoPay Tabungan',
    type: 'Harian & Belanja',
    balance: 7500000,
    icon: 'wallet',
    badge: 'E-Wallet',
    connected: true,
  },
  {
    id: 'bibit',
    name: 'Bibit Portofolio',
    type: 'Investasi Masa Depan',
    balance: 35000000,
    icon: 'monitoring',
    badge: 'Reksadana/SBN',
    connected: true,
  },
];

export const INITIAL_MO_POCKETS: MoPocketItem[] = [
  {
    id: 'keluarga',
    name: 'Keluarga',
    description: 'Living, proteksi, & pensiun mandiri',
    amount: 13750000,
    percentage: 55,
    color: 'bg-primary',
  },
  {
    id: 'ortu',
    name: 'Orang Tua',
    description: 'Kebutuhan medis rutin & nafkah',
    amount: 6250000,
    percentage: 25,
    color: 'bg-secondary',
  },
  {
    id: 'anak',
    name: 'Masa Depan Anak',
    description: 'Tabungan pendidikan & tumbuh kembang',
    amount: 5000000,
    percentage: 20,
    color: 'bg-primary-container',
  },
];

export const INITIAL_BUDGET_ITEMS: BudgetItem[] = [
  {
    id: 'ortu',
    title: 'Dukungan Ortu',
    subtitle: 'Bulanan & Obat Rutin',
    spent: 5100000,
    allocated: 6250000,
    status: 'Aman',
    icon: 'elderly',
    accentColor: 'primary',
  },
  {
    id: 'anak',
    title: 'Pendidikan & Tabungan Anak',
    subtitle: 'SPP & Kursus Eksplorasi',
    spent: 5000000,
    allocated: 5000000,
    status: 'Tepat Sasaran',
    icon: 'school',
    accentColor: 'secondary',
  },
  {
    id: 'rumah',
    title: 'Kebutuhan Rumah Tangga',
    subtitle: 'Dapur, Utilitas & Pemeliharaan',
    spent: 5900000,
    allocated: 7500000,
    status: 'Terkendali',
    icon: 'cottage',
    accentColor: 'primary',
  },
  {
    id: 'lifestyle',
    title: 'Gaya Hidup & Hiburan',
    subtitle: 'Hangout, Hobi & Langganan',
    spent: 3850000,
    allocated: 3500000,
    status: 'OVERBUDGET',
    icon: 'local_cafe',
    accentColor: 'error',
  },
  {
    id: 'emergency',
    title: 'Dana Darurat & Proteksi',
    subtitle: 'Asuransi Jiwa & Self-Preservation',
    spent: 2750000,
    allocated: 2750000,
    status: 'Terpenuhi',
    icon: 'health_and_safety',
    accentColor: 'primary-container',
  },
];

export const INITIAL_CHAT_MESSAGES: ChatMessage[] = [
  {
    id: '1',
    sender: 'user',
    text: 'Bagaimana cara menyeimbangkan uang jajan anak dengan biaya fisioterapi Ibu bulan ini tanpa membobol tabungan pensiunku?',
    timestamp: '14:23',
  },
  {
    id: '2',
    sender: 'ai',
    text: 'Halo Sarah! Pertanyaan yang sangat krusial bagi sandwich generation. Ini strategi 3 pilar yang saya kalkulasikan:',
    timestamp: '14:23',
    breakdown: [
      {
        badgeNumber: 1,
        title: 'Pilar Ibu (Kesehatan)',
        description: 'Fisioterapi (Rp 1.200.000) kita klaim reimburse asuransi murni 70%, sisanya Rp 360.000 dialihkan dari Kantong Ortu.',
      },
      {
        badgeNumber: 2,
        title: 'Pilar Anak (Edukasi)',
        description: 'Uang hobi & les anak tetap 100% utuh terjaga dari pos anggaran pendidikan bulanan.',
      },
      {
        badgeNumber: 3,
        title: 'Penyesuaian Fleksibel',
        description: 'Efisiensi sisa pos streaming & dine out yang belum terpakai sebesar Rp 400.000.',
      },
    ],
    highlight: 'Hasilnya: Tabungan pensiun Anda TETAP 100% aman bertambah Rp 3.500.000 bulan ini! 🎉',
    hasSimulationCard: true,
  },
];

export function formatRupiah(amount: number): string {
  return 'Rp ' + amount.toLocaleString('id-ID');
}
